# Mamo Ball CTF - libmain proxy + PlayerPowerConfig only (V4)

Alvo autorizado do CTF: `com.alberun.mamoball`.

Esta versão mantém a `libmain.so` como proxy/loader da Unity, preservando o bootstrap original:
- registra `com.unity3d.player.NativeLoader.load(String)` e `unload()`;
- carrega `libunity.so` e `libil2cpp.so`;
- inicia o ImGui só depois do carregamento nativo da Unity.

## Mudança da V4

A UI foi limpa para ficar somente com `PlayerPowerConfig`.

Removido da interface:
- Legacy;
- Move/Fly/NoClip;
- ESP;
- Info;
- chute direto em `BallController::Kick`;
- patch de `PlayerPower`.

## Hooks usados

Somente:
- `PlayerPowerConfig::.ctor`
- `BaseController::GetPlayerPowerConfig`

## Campos configuráveis

Todos os `ObscuredFloat` de `PlayerPowerConfig`, do `minPower` até `sizeFla`, com sliders de `0` até `1000`.

Campos incluídos:
- minPower, maxPower, maxPowerForVisual
- kickMin, kickMax, kickCurve, kickStr, kickAgi, kickFla
- powerKickMin, powerKickMax, powerKickCurve, powerKickStr, powerKickAgi, powerKickFla
- speedMin, speedMax, speedCurve, speedStr, speedAgi, speedFla
- sprintSpeedMin, sprintSpeedMax, sprintSpeedCurve, sprintSpeedStr, sprintSpeedAgi, sprintSpeedFla
- sprintDurationMin, sprintDurationMax, sprintDurationCurve, sprintDurationStr, sprintDurationAgi, sprintDurationFla
- massMin, massMax, massCurve, massStr, massAgi, massFla
- sizeMin, sizeMax, sizeCurve, sizeStr, sizeAgi, sizeFla

## Build pelo workflow ZIP

Suba este ZIP no root do repositório e use o workflow `build-from-zip.yml`.

ABI recomendado para a build atual:
- `arm64-v8a`

O output precisa ser renomeado/colocado como:

```text
libmain.so
```

## Teste no jogo

1. Substitua a `libmain.so` original pela gerada.
2. Abra o jogo.
3. No menu, toque em `Instalar hooks PlayerPowerConfig`.
4. Ative `Patch PlayerPowerConfig ativo`.
5. Ajuste os sliders ou use os botões rápidos.
6. Toque em `Reaplicar agora` quando quiser forçar o patch no objeto cacheado.

Touch/Input foi preservado.
