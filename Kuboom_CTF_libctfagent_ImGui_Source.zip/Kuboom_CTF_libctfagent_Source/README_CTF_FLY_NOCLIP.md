# CTF ImGui Loader — Fly + NoClip

Projeto ajustado para a build customizada do CTF `com.Nobodyshot.kuboom`.

## O que foi alterado

- Target package em `Main.cpp`: `com.Nobodyshot.kuboom`.
- Menu ImGui reduzido para:
  - `Fly`
  - `NoClip / atravessar paredes`
  - `Fly Speed`
- Hook em `PlayerScript::Update`.
- Offsets usados do `dump.cs` enviado:
  - `PlayerScript.controller`: `0xE0`
  - `PlayerScript.cameraComp`: `0x110`
  - `PlayerScript.moveDir`: `0x358`
  - `PlayerScript.grounded`: `0x36C`
  - controles `controlLeft/right/forward/backward/jump/down`: `0x39C` a `0x3A1`
- Fixes de build:
  - ABI alinhada para `arm64-v8a`
  - NDK fixado em `23.1.7779620`
  - manifest com `supportsRtl` duplicado corrigido
  - `Android.mk` com include `Dobby` corrigido
  - removido `-Werror`
  - Java `MainActivity` e `MenuService` mínimos adicionados
  - workflow GitHub Actions em `.github/workflows/android-build.yml`

## Build local

```bash
chmod +x ./gradlew
./gradlew clean assembleDebug
```

APK esperado:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Build no GitHub Actions

O workflow suporta dois modos:

1. Repositório com o projeto extraído.
2. Repositório contendo um ZIP no root, como `Loader_V3_CTF_FlyNoClip.zip` ou `ARQUIVOS.zip`.

Em ambos os casos, ele localiza `settings.gradle`, instala SDK/NDK e roda `assembleDebug`.
