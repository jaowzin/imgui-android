@echo off
set PKG=com.Nobodyshot.kuboom
set LIB=libctfagent-arm64-v8a.so

if not exist "%LIB%" (
  echo Nao achei %LIB% na pasta atual.
  echo Coloque o artifact do GitHub Actions aqui e rode de novo.
  exit /b 1
)

adb shell run-as %PKG% id
if errorlevel 1 (
  echo run-as falhou. O app precisa estar debuggable.
  exit /b 1
)

adb push "%LIB%" /sdcard/Download/libctfagent.so
adb shell run-as %PKG% mkdir -p files/ctf
adb shell run-as %PKG% cp /sdcard/Download/libctfagent.so files/ctf/libctfagent.so
adb shell run-as %PKG% chmod 700 files/ctf/libctfagent.so

adb shell monkey -p %PKG% 1
timeout /t 3 /nobreak >nul

adb shell am attach-agent %PKG% /data/data/%PKG%/files/ctf/libctfagent.so
adb logcat -d | findstr /i "CTF agent Agent_OnAttach Inject kuboom Dobby il2cpp fatal crash signal"
