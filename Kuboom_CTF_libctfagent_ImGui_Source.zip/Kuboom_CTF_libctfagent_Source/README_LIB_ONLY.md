# Build somente da lib

Este workflow compila somente a biblioteca nativa `libTool.so` via CMake direto, sem `assembleDebug` e sem gerar APK.

Artifact gerado:

```text
libTool-arm64-v8a.so
```

ou, se escolhido no `workflow_dispatch`:

```text
libTool-armeabi-v7a.so
```

O target CMake continua sendo `Tool`, então o nome interno da biblioteca é `libTool.so`.


## v8 runtime fix

- Build remains lib-only; no APK is built.
- Package-name gate removed from constructor/Zygisk path.
- Menu now opens by default.
- Old template expiry date disabled; it was hiding the logo/menu after 28-10-2025.
- Added extra logcat markers: `StartGUI called`, `eglSwapBuffers resolved`, `ImGui setup on first frame`.
