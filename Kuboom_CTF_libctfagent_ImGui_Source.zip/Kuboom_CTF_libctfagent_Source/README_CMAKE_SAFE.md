# CTF ImGui Loader - CMake Safe Build

This variant switches the native build from `ndk-build`/`Android.mk` to CMake.

Native artifact:

```text
app/build/intermediates/cmake/debug/obj/arm64-v8a/libTool.so
```

Runtime safety changes:

- no self `ptrace` / remote re-injection path from the constructor;
- only starts when the current process name is `com.Nobodyshot.kuboom`;
- waits for `eglSwapBuffers`, `libunity.so`, `libil2cpp.so`, and loaded IL2CPP assemblies;
- guards Unity `Input.get_touchCount` / `Input.GetTouch` before calling;
- keeps ImGui with only Fly + NoClip toggles.

Build locally:

```bash
./gradlew :app:assembleDebug
```

Build in GitHub Actions with `.github/workflows/android-build.yml`.
