# v10 input restore

This build keeps the CMake/lib-only pipeline, package gate disabled, and the Fly/NoClip menu,
but restores touch handling to the original loader style:

- no `AInputQueue_getEvent` hook is installed;
- menu touch is read via `UnityEngine.Input.get_touchCount` / `Input.GetTouch`;
- it tries `UnityEngine.dll` first, matching the original project that clicked correctly;
- `UnityEngine.CoreModule.dll` is only a fallback.

Build target remains `libTool.so` only.
