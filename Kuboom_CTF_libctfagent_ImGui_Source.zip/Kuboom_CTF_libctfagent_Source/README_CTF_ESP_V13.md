# CTF ImGui Loader v13 - ESP

Build lib-only com CMake/Ninja.

Recursos adicionados nesta versão:

- Categoria nova no ImGui: `ESP`
- `Enable ESP`
- `Line`
- `Box`
- `Vida / Health Bar`
- `Distancia`
- `Team Check`
- sliders para vida máxima, espessura da linha e box

Implementação:

- coleta players via hook em `PlayerScript::Update`
- limpa ponteiros via hook em `PlayerScript::OnDestroy`
- usa `Camera.WorldToScreenPoint` para projetar coordenadas 3D na tela
- lê `PlayerScript.health` em `0x280`
- lê `PlayerScript.team` em `0x298`
- mantém Fly, Safe NoClip/Phase e Bypass ACMON da v12

Build:

```bash
cmake -S app/src/main/jni -B _native_build/arm64-v8a -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake \
  -DANDROID_ABI=arm64-v8a \
  -DANDROID_PLATFORM=android-19 \
  -DCMAKE_BUILD_TYPE=Release

cmake --build _native_build/arm64-v8a --target Tool
```

Artifact esperado no GitHub Actions:

```text
libTool-arm64-v8a.so
```
