# Mamo Ball CTF - V12 Toggle Sprint

Build CTF Unity Android para `com.alberun.mamoball`.

## Mudanças V12

- Mantém `libmain.so` como proxy/loader Unity.
- Touch/Input não foi alterado.
- Removido botão separado de instalar hooks.
- Cada toggle instala os hooks de power automaticamente quando ligado:
  - Chute normal
  - Super chute
  - Sprint speed
- Sliders de 0 até 1000.
- Menu menor, sem abas extras.
- Removidos do grupo estável:
  - PlayerPowerConfig
  - PlayerPower/stats do personagem
  - BallController::Kick
  - CharacterManager/HeroListItem
  - Ads/Unlock no menu

## Uso

1. Chegue no lobby.
2. Abra o menu.
3. Ligue `Chute normal`, `Super chute` ou `Sprint speed`.
4. Ajuste os sliders.
5. A primeira função ligada solicita os hooks automaticamente.
6. O patch é aplicado nos próximos getters/setters de `PlayerPower`.

## Build

Pode usar o mesmo fluxo `build-from-zip.yml`: subir o ZIP no root do repositório e rodar o workflow.
O artifact arm64 deve ser renomeado para `libmain.so` antes de substituir a lib da build CTF.


V12: toggle `Tirar ads` voltou ao menu. Instala hooks sob demanda e mantém callbacks desligados por padrão para estabilidade.


V12: toggle `Tirar ads` voltou ao menu. Instala hooks sob demanda e mantém callbacks desligados por padrão para estabilidade.
