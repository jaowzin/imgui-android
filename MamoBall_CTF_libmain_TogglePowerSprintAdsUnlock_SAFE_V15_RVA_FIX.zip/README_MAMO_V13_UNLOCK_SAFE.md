# Mamo Ball CTF - V13 Safe Unlock

Base: V12 estável.

Mudanças:
- Mantém chute normal, super chute, sprint e tirar ads.
- Adiciona toggle `Unlock all personagens`.
- Unlock não ativa no boot.
- Hooks de unlock instalam somente quando o toggle é ligado.
- Modo de unlock é client-side/safe:
  - CharacterManager::IsHeroClaimed
  - CharacterManager::IsHeroClaimable
  - CharacterManager::GetHeroListItem
  - CharacterManager::GetClaimedOrClaimableHeroCount
  - HeroListItem::GetLevel
  - HeroListItem::IsMaxLevel
  - HeroListItem::GetPower
  - HeroListItem::IsUpgradable
  - HeroListItemLayout::SetData
  - HeroListItemLayout::Select
  - CharacterFragmentCardsLayout::SetHeroListItem

Evita:
- HeroListItem::.ctor
- CharacterManager::GetHeroListItems
- CharacterManager::PrepareHeroListItems
- varrer listas inteiras em cena/lobby

Observação:
Se a build validar personagem no servidor do laboratório, o unlock pode ser apenas visual/local.
