# Mamo Ball CTF - V10 Stable Manual Power

Esta versão mantém a `libmain.so` como proxy/loader Unity e não altera Touch/Input.

## Mudanças contra lag/crash da V9

- Removeu reaplicação automática em loop a cada 1 segundo.
- Não escreve mais em ponteiros cacheados diretamente após troca de cena.
- Adicionou cache bounded de patch por objeto/versão.
- `GenerateKey` do `ObscuredFloat` não é chamado em todo patch.
- Botão principal agora ativa somente o chute 1000 estável.
- Power físico do personagem em 1000 ficou separado e experimental, pois pode quebrar física/causar lag/crash.

## Uso

1. Abra o jogo e chegue no lobby.
2. Abra o menu.
3. Clique em `Instalar hooks seguros de power`.
4. Clique em `Ativar chute 1000 estavel`.

Não ative `Power/stats personagem` no primeiro teste. Teste o chute 1000 sozinho por alguns minutos.


V12: adiciona toggle `Tirar ads` de volta ao menu. Os hooks de ads só instalam quando o toggle é ligado, com callbacks desligados por padrão para estabilidade.


V12: toggle `Tirar ads` voltou ao menu. Instala hooks sob demanda e mantém callbacks desligados por padrão para estabilidade.
