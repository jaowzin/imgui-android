# Mamo Ball CTF - libmain Unity Proxy ImGui V7

Build CTF alvo: `com.alberun.mamoball`.

## O que mudou na V7

- Mantem a `libmain.so` como proxy/loader da Unity, igual a V3 que abriu.
- Volta o layout antigo estilo Loader com abas (`Mamo Power`, `Ads`, `Unlock`).
- Remove auto-install de AdManager e CharacterManager para evitar crash no lobby.
- No boot, nenhum hook de gameplay/ads/unlock instala sozinho.
- `Touch/Input` não foi alterado.
- Chute normal e super chute continuam configuráveis de `0` a `1000`.
- `Tirar anuncios` fica marcado no menu, mas os hooks de ads precisam ser instalados manualmente na aba Ads.
- Unlock all personagens/heroes fica experimental/manual na aba Unlock.

## Ordem recomendada de teste

1. Substitua a `libmain.so`.
2. Abra o jogo e espere chegar no lobby.
3. Abra o menu.
4. Aba `Mamo Power` -> `Instalar hooks de chute`.
5. Teste chute normal/super chute.
6. Só depois, se o lobby estiver estável:
   - Aba `Ads` -> `Instalar hooks de anuncios`.
   - Aba `Unlock` -> `Instalar hooks de unlock`.

Se crashar ao clicar em Ads ou Unlock, o problema fica isolado nesse grupo de hooks, sem quebrar o boot/lobby.

## GitHub Actions

Pode usar o workflow incluído em `.github/workflows/android-build.yml` ou o workflow externo `build-from-zip.yml`.

ABI recomendado: `arm64-v8a`.

O artifact final deve ser renomeado para:

```text
libmain.so
```
