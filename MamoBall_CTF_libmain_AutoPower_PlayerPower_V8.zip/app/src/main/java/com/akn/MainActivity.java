package com.akn;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    static {
        try {
            System.loadLibrary("Tool");
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView tv = new TextView(this);
        tv.setText("CTF Loader - Fly/NoClip\nTarget: com.Nobodyshot.kuboom");
        tv.setPadding(32, 32, 32, 32);
        setContentView(tv);

        try {
            startService(new Intent(this, MenuService.class));
        } catch (Throwable ignored) {
        }
    }
}
