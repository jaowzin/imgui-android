package com.akn;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class MenuService extends Service {
    static {
        try {
            System.loadLibrary("Tool");
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }
}
