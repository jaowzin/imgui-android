# Mamo Ball CTF - libmain Unity Proxy ImGui SAFE V6

Build CTF autorizada: `com.alberun.mamoball`.

## Conteúdo

- Mantém `libmain.so` como proxy/loader da Unity.
- Preserva `NativeLoader.load/unload`.
- Não altera Touch/Input.
- Menu ImGui limpo com:
  - Chute normal `0..1000`
  - Super chute `0..1000`
  - Tirar anúncios em modo seguro, habilitado por padrão
  - Unlock all personagens/heroes, habilitado por padrão

## Por que V6

A V5 podia crashar no lobby porque chamava `System.Action.Invoke` diretamente nos hooks de anúncio.  
Na V6 os callbacks de anúncio ficam desligados por padrão. O bloqueio de anúncio usa modo seguro:

- `AdManager` state patch
- SDK init skip
- banner/MRec/interstitial/rewarded bloqueados
- readiness de ads retorna `false`

Existe a opção avançada `chamar callback do anuncio`, mas deixe desligada no primeiro teste.

## Hooks principais

### PlayerPowerConfig

- `PlayerPowerConfig::.ctor`
- `BaseController::GetPlayerPowerConfig`

Offsets usados:

- `minPower = 0x10`
- `maxPower = 0x24`
- `maxPowerForVisual = 0x38`
- `kickMin = 0x4C`
- `kickMax = 0x60`
- `powerKickMin = 0xC4`
- `powerKickMax = 0xD8`

### Ads safe

- `AdManager::.ctor`
- `AdManager::OnAControllerStart`
- `AdManager::InitAppLovinMaxIfNeeded`
- `AdManager::ShowInterstitial`
- `AdManager::ShowRewarded`
- `AdManager::ShowBanner`
- `AdManager::ShowMRec`
- `AdManager::IsInterstitialReady`
- `AdManager::IsRewardedReady`
- `AdManager::IsBannerReady`
- `AdManager::IsMRecReady`
- `AdManager::IsBannerAdActive`

### Unlock all personagens/heroes

- `HeroListItem::.ctor`
- `CharacterManager::IsHeroClaimed`
- `CharacterManager::IsHeroClaimable`
- `CharacterManager::GetHeroListItems`
- `CharacterManager::PrepareHeroListItems`
- `CharacterManager::GetClaimedOrClaimableHeroCount`

## Build pelo GitHub Actions

1. Suba este ZIP no root do repositório.
2. Garanta que o workflow externo existe em:

```text
.github/workflows/build-from-zip.yml
```

3. Rode:

```text
Actions > Build libmain.so from uploaded ZIP > Run workflow
```

Use:

```text
abi = arm64-v8a
zip_name = AUTO
```

4. Baixe o artifact e renomeie para:

```text
libmain.so
```

5. Substitua a `libmain.so` original da build CTF.

## Log se crashar

```bash
adb logcat -c
adb shell am force-stop com.alberun.mamoball
adb shell monkey -p com.alberun.mamoball 1
adb logcat -d | grep -Ei "UnityProxy|Mamo|AdManager|CharacterManager|HeroListItem|libmain|libunity|libil2cpp|dobby|fatal|crash|signal|tombstone"
```
