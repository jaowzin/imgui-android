# Mamo Ball CTF - libmain Unity Proxy ImGui V8 Auto Power

Pacote alvo: `com.alberun.mamoball`

Esta versão mantém a `libmain` como proxy/loader da Unity, igual à V3/V7 que abriu o jogo sem quebrar o bootstrap.

## Mudanças V8

- Hooks de power/chute instalam automaticamente depois que `libunity.so` e `libil2cpp.so` carregam.
- Chute normal padrão: `1000`.
- Super chute padrão: `1000`.
- Power/stats do personagem padrão: `1000`.
- Adicionado patch direto em `PlayerPower`:
  - `kickStrength`
  - `powerKickStrength`
  - `mass`
  - `playerSpeed`
  - `sprintSpeed`
  - `sprintDuration`
  - `playerSize`
- Adicionado hook em:
  - `PlayerPowerConfig::.ctor`
  - `BaseController::GetPlayerPowerConfig`
  - `Player::GetPlayerPower`
  - `Character::GetPlayerPower`
  - `PlayerController::GetPlayerPower`
  - `PlayerController::SetPlayerPower`
  - `BallController::Kick`
  - `CharacterManager::GetHeroStrength`
  - `CharacterManager::GetHeroAgility`
  - `CharacterManager::GetHeroFlair`
  - `CharacterManager::GetHeroAvgPower`
  - `Character::GetStrength`
  - `Character::GetAgility`
  - `Character::GetFlair`
  - `Character::GetPower`
  - `HeroListItem::GetPower`
  - `HeroLevel::GetPower`
  - `HeroReward::GetAvgPower`

## Sobre unlock all

O unlock all antigo não ficou automático porque travava/crashava ao clicar para ver personagem.  
Nesta V8 o modo seguro não altera a lista de `HeroListItem`; ele força o power/stats retornado por getters do personagem.

## Build GitHub Actions

Suba este ZIP no root do repo e use o workflow `build-from-zip.yml`.

Artifact esperado:

- `libmain.so`
- `libmain-arm64-v8a.so`

Use o `libmain-arm64-v8a.so`, renomeie para `libmain.so` e substitua a lib da build CTF.
