# Mamo Ball CTF - libmain V9 SAFE MANUAL

Build CTF autorizada: `com.alberun.mamoball`.

## O que mudou na V9

- Mantém `libmain.so` como proxy/loader Unity.
- Touch/Input preservados.
- Nada de power/chute/ads/unlock ativa sozinho no boot.
- Hooks seguros de power são instalados manualmente no menu após chegar no lobby.
- `BallController::Kick`, `CharacterManager` e `HeroListItem` não entram no grupo seguro.
- Normal e super chute são separados via `PlayerPowerConfig` e `PlayerPower`, sem forçar o mesmo valor em `BallController::Kick`.

## Uso recomendado

1. Buildar pelo workflow ZIP.
2. Substituir a `libmain.so` arm64 na build CTF.
3. Abrir o jogo e esperar o lobby.
4. Abrir o menu.
5. `Mamo Power` -> `Instalar hooks seguros de power`.
6. Depois clicar `Ativar patches + aplicar 1000`.

## Valores

- Chute normal: `0..1000`.
- Super chute: `0..1000`.
- Power personagem: `0..1000`.

Se crashar mesmo antes de instalar hooks, o problema é no loader/proxy ou em init ImGui/EGL, não nos hooks de power.
