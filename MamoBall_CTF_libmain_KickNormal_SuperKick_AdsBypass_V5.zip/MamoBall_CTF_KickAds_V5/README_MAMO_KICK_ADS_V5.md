# Mamo Ball CTF - libmain proxy + Kick/Ads V5

Alvo autorizado do CTF: `com.alberun.mamoball`.

Esta versão mantém a `libmain.so` como proxy/loader da Unity, preservando o bootstrap original:
- registra `com.unity3d.player.NativeLoader.load(String)` e `unload()`;
- carrega `libunity.so` e `libil2cpp.so`;
- inicia o ImGui depois do carregamento nativo da Unity;
- não altera a lógica de Touch/Input.

## Interface final

A UI ficou somente com:

- `Patch chute ativo`;
- `Tirar anuncios`, habilitado por padrão;
- slider `Chute normal`, range `0..1000`;
- slider `Super chute`, range `0..1000`;
- botões `Aplicar 1000 / 1000`, `Reset padrao` e `Reaplicar`.

## PlayerPowerConfig

A build usa `PlayerPowerConfig` com `ObscuredFloat` de 0x14 bytes.

O slider `Chute normal` aplica:

- `minPower` em `0x10`;
- `maxPower` em `0x24`;
- `maxPowerForVisual` em `0x38`;
- `kickMin` em `0x4C`;
- `kickMax` em `0x60`.

O slider `Super chute` aplica:

- `powerKickMin` em `0xC4`;
- `powerKickMax` em `0xD8`.

Os valores começam em `1000 / 1000` e podem ser ajustados de `0` até `1000`.

## Ads bypass

A opção `Tirar anuncios` começa ligada por padrão.

Hooks usados no `AdManager`:

- `.ctor`;
- `InitAppLovinMaxIfNeeded`;
- `ShowInterstitial`;
- `ShowRewarded`;
- `ShowBanner`;
- `ShowMRec`;
- `IsInterstitialReady`;
- `IsRewardedReady`;
- `IsBannerReady`;
- `IsMRecReady`;
- `IsBannerAdActive`.

Interstitial e rewarded são pulados e tentam chamar o `Action onCompleteAction`, quando resolvido, para não travar fluxo interno da build do CTF.

## Build no GitHub Actions

Se você já tem o workflow `build-from-zip.yml` no repositório:

1. Suba este ZIP no root do repo.
2. Vá em `Actions`.
3. Rode `Build libmain.so from uploaded ZIP`.
4. Use `abi = arm64-v8a`.
5. Baixe o artifact.
6. Renomeie o `.so` final para `libmain.so`.

## Instalação com root

Substitua somente a `libmain.so` do pacote CTF:

```bash
PKG=com.alberun.mamoball
APK=$(pm path $PKG | head -n1 | sed 's/package://')
APPDIR=$(dirname "$APK")
find "$APPDIR" -name "libmain.so" -print
```

Faça backup da original antes de trocar.
