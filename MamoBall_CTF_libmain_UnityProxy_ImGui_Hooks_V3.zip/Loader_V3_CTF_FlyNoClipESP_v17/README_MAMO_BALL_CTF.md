# Mamo Ball CTF - libmain ImGui Loader

Build personalizada alvo: `com.alberun.mamoball`.

## O que foi alterado

- O output nativo agora sai como `libmain.so`.
- A parte de Touch/Input foi preservada como estava na source original.
- Os hooks antigos de Kuboom/Fly/NoClip/ESP ficam desligados por padrão para evitar crash no Mamo Ball.
- Foi adicionada a aba **Mamo Power** no ImGui.

## Hooks adicionados

Offsets confirmados no `dump.cs` enviado:

### `PlayerPowerConfig`

```cpp
minPower            0x10
maxPower            0x24
maxPowerForVisual   0x38
kickMin             0x4C
kickMax             0x60
powerKickMin        0xC4
powerKickMax        0xD8
```

Hooks usados:

```cpp
PlayerPowerConfig::.ctor()
BaseController::GetPlayerPowerConfig()
```

### `PlayerPower`

```cpp
kickStrength        0x10
powerKickStrength   0x24
```

Hooks usados:

```cpp
Player::GetPlayerPower()
PlayerController::GetPlayerPower()
PlayerController::SetPlayerPower(PlayerPower)
```

### Chute direto

Hook usado:

```cpp
BallController::Kick(Vector2 playerPosition, MatchPlayer kickingMatchPlayer, PlayerInput input, float kickStrength)
```

O hook altera apenas o argumento `kickStrength`, sem mexer em `Touch`, `Input`, joystick ou botões do jogo.

## Build pelo GitHub Actions

Você pode subir este ZIP inteiro em um repositório GitHub. O workflow aceita dois formatos:

1. Repositório com a pasta do projeto já extraída.
2. Repositório contendo apenas este ZIP na raiz.

Depois execute:

`Actions -> Build libmain.so - Mamo Ball CTF -> Run workflow`

O artifact gerado será:

```text
libmain.so
libmain-arm64-v8a.so
```

ABI padrão: `arm64-v8a`.

## Uso no CTF

Carregue o `libmain.so` pelo loader autorizado do laboratório. Ao abrir o menu ImGui:

- Ative/desative **Chute forte**.
- Ajuste **Valor do chute**.
- Ajuste `minPower`, `maxPower`, `kickMax`, `powerKickMax`.
- Use **Reaplicar agora** para reaplicar nos objetos já cacheados.

## Observação

Se algum hook aparecer como `target missing` no logcat, a lib continua carregando e o menu permanece vivo. Isso evita crash quando um método muda de nome ou ainda não foi carregado.
