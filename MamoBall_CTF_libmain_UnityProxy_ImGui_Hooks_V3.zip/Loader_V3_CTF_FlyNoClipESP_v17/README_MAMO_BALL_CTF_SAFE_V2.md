# Mamo Ball CTF - libmain ImGui Loader Safe v2

Alvo autorizado do CTF: `com.alberun.mamoball`.

## Por que esta versão foi feita

A versão anterior podia crashar porque instalava hooks automaticamente e tentava criar `ObscuredFloat` chamando `ObscuredFloat.op_Implicit(float)` como se retornasse a struct diretamente. No arm64, `ObscuredFloat` tem 0x14 bytes e usa ABI de retorno por ponteiro oculto, então essa chamada pode corromper registradores/stack.

Esta Safe v2 muda isso:

- nenhum hook de gameplay instala automaticamente no boot;
- `Chute forte` começa desligado;
- `Patch PlayerPowerConfig` começa desligado;
- `Patch PlayerPower atual` começa desligado;
- o menu ImGui abre primeiro;
- você instala os hooks manualmente pelo botão **Instalar hooks Mamo agora**;
- por padrão instala somente `BallController::Kick`, que é o caminho mais estável;
- os hooks de `PlayerPowerConfig` e `PlayerPower` só entram se marcar a opção avançada antes de instalar;
- não foi mexido no bloco de touch/input.

## Uso recomendado

1. Troque a lib e abra o jogo.
2. Confirme que o jogo abre sem crash e que o menu aparece.
3. Na aba **Mamo Power**, clique em **Instalar hooks Mamo agora** sem marcar a opção avançada.
4. Ative **Chute forte**.
5. Teste o chute.
6. Só depois teste **Instalar hooks PlayerPowerConfig/PlayerPower junto (avancado)** em uma build separada, se precisar mexer em `minPower/maxPower`.

## Build no GitHub Actions

Suba este ZIP no repositório e deixe um workflow externo em:

```text
.github/workflows/build-from-zip.yml
```

O workflow precisa extrair o ZIP e rodar o build Android/NDK. O output final deve ser renomeado/colocado como:

```text
libmain.so
```

Para arm64 use:

```text
arm64-v8a
```

## Instalação com root

Backup primeiro:

```bash
adb push libmain-arm64-v8a.so /data/local/tmp/libmain.so
adb shell
su
PKG=com.alberun.mamoball
APK=$(pm path $PKG | head -n1 | sed 's/package://')
APPDIR=$(dirname "$APK")
find "$APPDIR" -name "libmain.so" -print
```

Substitua o alvo encontrado:

```bash
TARGET=/data/app/~~xxxx/com.alberun.mamoball-yyyy==/lib/arm64/libmain.so
cp -a "$TARGET" "$TARGET.bak"
cat /data/local/tmp/libmain.so > "$TARGET"
chmod 755 "$TARGET"
restorecon "$TARGET" 2>/dev/null
am force-stop com.alberun.mamoball
```

Se crashar:

```bash
cat "$TARGET.bak" > "$TARGET"
chmod 755 "$TARGET"
restorecon "$TARGET" 2>/dev/null
am force-stop com.alberun.mamoball
```

## Logcat para diagnóstico

```bash
adb logcat -c
adb shell am force-stop com.alberun.mamoball
adb shell monkey -p com.alberun.mamoball 1
adb logcat -d | grep -Ei "CTF|Mamo|libmain|il2cpp|dobby|fatal|crash|tombstone|signal|dlopen"
```
