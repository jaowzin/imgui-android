# Mamo Ball CTF - libmain Unity Proxy V3

Esta versão corrige o crash de bootstrap do Unity.

## Por que a versão anterior crashava

A `libmain.so` original da build Unity não é uma lib comum de gameplay. Ela registra os natives:

- `com.unity3d.player.NativeLoader.load(Ljava/lang/String;)Z`
- `com.unity3d.player.NativeLoader.unload()Z`

e depois carrega:

- `libunity.so`
- `libil2cpp.so`

Se a `libmain.so` original é substituída por uma lib ImGui comum que só tem `JNI_OnLoad`, o Unity perde o loader nativo e o app pode crashar antes do menu abrir.

## O que mudou na V3

- `libmain.so` continua sendo o nome final.
- `JNI_OnLoad` agora registra `NativeLoader.load` e `NativeLoader.unload`, igual à lib Unity original.
- `NativeLoader.load` faz `dlopen` em `libunity.so` e `libil2cpp.so`.
- Se essas libs tiverem `JNI_OnLoad`, ele é chamado.
- O thread do ImGui só começa depois que `libunity.so` carrega.
- Não há `__attribute__((constructor))` iniciando ImGui antes do bootstrap do Unity.
- Touch/Input não foi alterado.

## Build

Use o workflow externo `build-from-zip.yml` no repositório e envie este ZIP no root do repo.

Input recomendado:

- `zip_name`: `AUTO`
- `abi`: `arm64-v8a`

O artifact gerado terá:

- `libmain.so`
- `libmain-arm64-v8a.so`

Use `libmain.so` no jogo.

## Instalação com root

Backup primeiro:

```sh
PKG=com.alberun.mamoball
APK=$(pm path $PKG | head -n1 | sed 's/package://')
APPDIR=$(dirname "$APK")
find "$APPDIR" -name "libmain.so" -print
```

Troca:

```sh
TARGET=/data/app/~~xxxx/com.alberun.mamoball-yyyy==/lib/arm64/libmain.so

cp -a "$TARGET" "$TARGET.bak"
cat /data/local/tmp/libmain.so > "$TARGET"
chmod 755 "$TARGET"
restorecon "$TARGET" 2>/dev/null
am force-stop com.alberun.mamoball
```

Se crashar:

```sh
cat "$TARGET.bak" > "$TARGET"
chmod 755 "$TARGET"
restorecon "$TARGET" 2>/dev/null
am force-stop com.alberun.mamoball
```

## Log para debug

```sh
adb logcat -c
adb shell am force-stop com.alberun.mamoball
adb shell monkey -p com.alberun.mamoball 1
adb logcat -d | grep -Ei "UnityProxy|NativeLoader|libmain|libunity|libil2cpp|fatal|crash|signal|tombstone|UnsatisfiedLinkError"
```
