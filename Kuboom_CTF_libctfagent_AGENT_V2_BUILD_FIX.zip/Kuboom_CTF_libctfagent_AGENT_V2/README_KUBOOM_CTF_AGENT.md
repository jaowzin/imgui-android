# Kuboom CTF libctfagent - V2

Pacote alvo: `com.Nobodyshot.kuboom`

Esta versão mantém os hooks existentes e só corrige o build do agent:
- adiciona declaração antecipada de `hack_thread`;
- mantém `Agent_OnAttach`;
- gera `libctfagent.so`;
- não altera hooks/gameplay.

## Caminho recomendado para carregar

Use `code_cache` dentro do sandbox do app, porque o `am attach-agent` precisa que o processo do app consiga ler e mapear a `.so`.

No Windows CMD:

```bat
adb shell run-as com.Nobodyshot.kuboom id
adb push libctfagent-arm64-v8a.so /sdcard/Download/libctfagent.so
adb shell run-as com.Nobodyshot.kuboom sh -c "mkdir -p code_cache/ctf && cp /sdcard/Download/libctfagent.so code_cache/ctf/libctfagent.so && chmod 700 code_cache/ctf/libctfagent.so"
adb shell monkey -p com.Nobodyshot.kuboom -c android.intent.category.LAUNCHER 1
adb shell am attach-agent com.Nobodyshot.kuboom /data/user/0/com.Nobodyshot.kuboom/code_cache/ctf/libctfagent.so
```

Alternativa equivalente:

```bat
adb shell am attach-agent com.Nobodyshot.kuboom /data/data/com.Nobodyshot.kuboom/code_cache/ctf/libctfagent.so
```

Evite `/sdcard` para `attach-agent`, porque normalmente é `noexec`.
`/data/local/tmp` pode falhar por SELinux em vários aparelhos.

---

# Kuboom CTF - libctfagent via ADB attach-agent

Pacote alvo do CTF:

```text
com.Nobodyshot.kuboom
```

Esta source foi ajustada para gerar uma lib JVMTI agent:

```text
libctfagent.so
```

Ela mantém os hooks existentes da source e adiciona somente a entrada necessária para injeção via ADB:

```cpp
Agent_OnAttach(JavaVM* vm, char* options, void* reserved)
```

## Build no GitHub Actions

O workflow esperado no repositório é:

```text
.github/workflows/build-from-zip.yml
```

Suba o ZIP da source no root do repo e rode:

```text
Actions > Build libctfagent.so from uploaded ZIP > Run workflow
```

Use:

```text
zip_name = AUTO
abi = arm64-v8a
```

O artifact sai como:

```text
libctfagent-arm64-v8a.so
libctfagent.so
```

## Injeção sem root

Confirme primeiro que o jogo está debuggable:

```bat
adb shell run-as com.Nobodyshot.kuboom id
```

Copie a lib para o sandbox privado do app:

```bat
adb push libctfagent-arm64-v8a.so /sdcard/Download/libctfagent.so
adb shell run-as com.Nobodyshot.kuboom mkdir -p files/ctf
adb shell run-as com.Nobodyshot.kuboom cp /sdcard/Download/libctfagent.so files/ctf/libctfagent.so
adb shell run-as com.Nobodyshot.kuboom chmod 700 files/ctf/libctfagent.so
```

Abra o jogo e injete:

```bat
adb shell monkey -p com.Nobodyshot.kuboom 1
adb shell am attach-agent com.Nobodyshot.kuboom /data/data/com.Nobodyshot.kuboom/files/ctf/libctfagent.so
```

Se o attach por pacote falhar, use PID:

```bat
for /f %p in ('adb shell pidof com.Nobodyshot.kuboom') do adb shell am attach-agent %p /data/data/com.Nobodyshot.kuboom/files/ctf/libctfagent.so
```

Dentro de arquivo `.bat`, use `%%p`.

## Logcat

```bat
adb logcat -c
adb shell am attach-agent com.Nobodyshot.kuboom /data/data/com.Nobodyshot.kuboom/files/ctf/libctfagent.so
adb logcat -d | findstr /i "CTF agent Agent_OnAttach Inject kuboom Dobby il2cpp fatal crash signal"
```
