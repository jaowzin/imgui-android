@echo off
set PKG=com.Nobodyshot.kuboom
set LOCAL_LIB=libctfagent-arm64-v8a.so
if not exist "%LOCAL_LIB%" set LOCAL_LIB=libctfagent.so

echo [*] Verificando run-as...
adb shell run-as %PKG% id || goto :err

echo [*] Enviando lib para /sdcard/Download...
adb push "%LOCAL_LIB%" /sdcard/Download/libctfagent.so || goto :err

echo [*] Copiando para code_cache do app...
adb shell run-as %PKG% sh -c "mkdir -p code_cache/ctf && cp /sdcard/Download/libctfagent.so code_cache/ctf/libctfagent.so && chmod 700 code_cache/ctf/libctfagent.so" || goto :err

echo [*] Abrindo jogo...
adb shell monkey -p %PKG% -c android.intent.category.LAUNCHER 1

echo [*] Aguardando processo...
timeout /t 5 /nobreak >nul

echo [*] Injetando agent...
adb shell am attach-agent %PKG% /data/user/0/%PKG%/code_cache/ctf/libctfagent.so || goto :err

echo [*] OK. Logs:
adb logcat -d | findstr /i "CTF_AGENT Agent_OnAttach kuboom il2cpp Dobby fatal crash signal"
exit /b 0

:err
echo [!] Falhou. Verifique se o app esta debuggable e se a ABI da lib e arm64-v8a.
exit /b 1
