// --- C Standard ---
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <math.h>
#include <limits>
#include <cstring>
#include <ctime>

// --- C++ Standard ---
#include <thread>
#include <vector>
#include <fstream>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <mutex>
#include <atomic>

// --- Android / System / Dynamic loading ---
#include <android/log.h>
#include <android/input.h>
#include <dlfcn.h>
#include <pthread.h>
#include <sys/system_properties.h>

// --- Graphics ---
#include <EGL/egl.h>
#include <GLES3/gl3.h>

// --- External libs / hooks / utilities ---
#include <xdl.h>
#include <SubstrateHook.h>
#include <CydiaSubstrate.h>

// --- KittyMemory (memory tools) ---
#include <KittyMemory/KittyMemory.h>
#include <KittyMemory/MemoryPatch.h>
#include <KittyMemory/KittyScanner.h>
#include <KittyMemory/KittyUtils.h>
#include <KittyUtils.h>

// --- ImGui ---
#include "imgui.h"
#include "imgui_internal.h"
#include "imgui_impl_android.h"
#include "imgui_impl_opengl3.h"

// --- Project / Local headers ---
#include "include/Tools.hpp"
#include "include/obfuscate.h"
#include "include/Theme.h"
#include "imgui/Font.h"
#include "imgui/Roboto-Regular.h"
#include "QQInj.h"
#include "imgui/Icon.h"
#include "imgui/Iconcpp.h"
#include "AutoUpdate/IL2CppSDKGenerator/Il2Cpp.h"
#include "AutoUpdate/Tools/Call_Tools.h"
#include "Zygisk.hpp"


inline static int g_GlHeight, g_GlWidth;
inline static bool g_IsSetup = false;
inline int prevWidth, prevHeight;

std::string GetProp(const char* key) {
  char value[PROP_VALUE_MAX];
  __system_property_get(key, value);
  return std::string(value);
}

using zygisk::Api;
using zygisk::AppSpecializeArgs;
using zygisk::ServerSpecializeArgs;

// Loader build: do not gate startup by package name.
// The external loader is responsible for loading this library into the target CTF process.
// Keeping a package-name check here can block startup when the process name differs
// from the visible package name or when the loader uses an isolated/instrumented process.
static constexpr bool kDisablePackageGate = true;
char packageName[] = "com.Nobodyshot.kuboom";

// ================= CTF movement toggles =================
// ImGui controls only: Fly + NoClip for the isolated Kuboom CTF build.
static bool FlyHack = false;
static bool NoClipHack = false;
static bool AntiCheatBypass = true;
static float FlySpeed = 12.0f;
static void* g_LocalPlayer = nullptr;

// Offsets from the supplied dump.cs: PlayerScript fields.
static constexpr uintptr_t OFF_PLAYER_CONTROLLER = 0xE0;
static constexpr uintptr_t OFF_PLAYER_CAMERA     = 0x110;
static constexpr uintptr_t OFF_PLAYER_MOVEDIR    = 0x358;
static constexpr uintptr_t OFF_PLAYER_GROUNDED   = 0x36C;
static constexpr uintptr_t OFF_CTRL_LEFT         = 0x39C;
static constexpr uintptr_t OFF_CTRL_RIGHT        = 0x39D;
static constexpr uintptr_t OFF_CTRL_FORWARD      = 0x39E;
static constexpr uintptr_t OFF_CTRL_BACKWARD     = 0x39F;
static constexpr uintptr_t OFF_CTRL_JUMP         = 0x3A0;
static constexpr uintptr_t OFF_CTRL_DOWN         = 0x3A1;

// ================= CTF ESP toggles =================
// Hook PlayerScript::Update to collect active player instances, then draw
// screen-space overlays through UnityEngine.Camera::WorldToScreenPoint.
static bool EspEnable = false;
static bool EspLine = true;
static bool EspBox = true;
static bool EspHealth = true;
static bool EspDistance = false;
static bool EspTeamCheck = true;
static float EspMaxHealth = 100.0f;
static float EspLineThickness = 2.0f;
static float EspBoxThickness = 2.0f;

// ESP v14 calibration:
// v13 used PlayerScript.transform + local player cameraComp. In Kuboom this can point
// to the player root / wrong camera and the overlay lands on map pivots instead of the
// visible character. v14 defaults to Camera.main + CharacterController/head renderer.
static bool EspUseMainCamera = true;
static bool EspUseControllerPos = true;
static bool EspUseHeadRenderer = true;
static bool EspFlipY = true;
static bool EspDebugPoint = false;
static float EspHeightOffset = 0.05f;

// ESP v15:
// Wall ESP should not depend on Renderer/head transforms. Some Unity builds stop
// updating/cull renderer transforms when the player is behind geometry, which makes
// the box disappear even though the network position is still valid.
static bool EspWallMode = true;
static bool EspUseNetworkPos = true;
static bool EspSkipUninitialized = false;
static bool EspStabilize = true;
static bool EspSkipDead = false;
static float EspCacheSeconds = 1.25f;

// Team filter repair. In this Kuboom CTF build the raw team field can be inverted or
// not synchronized on some players. Use PlayerScript::getTeam() when available and
// keep an invert toggle in the menu. Default ON because the last test showed allies
// passing through the enemy filter.
static bool EspInvertTeamLogic = true;
static int g_EspRendered = 0;
static int g_EspSkippedTeam = 0;
static int g_EspSkippedPos = 0;
static int g_EspSkippedW2S = 0;
static int g_EspLocalTeamDbg = -9999;

static constexpr uintptr_t OFF_PLAYER_HEALTH      = 0x280;
static constexpr uintptr_t OFF_PLAYER_TEAM        = 0x298;
static constexpr uintptr_t OFF_PLAYER_INITIALIZED = 0x2B0;
static constexpr uintptr_t OFF_PLAYER_SKIN        = 0x458;
static constexpr uintptr_t OFF_PLAYER_HEAD_RENDER = 0x460;
static constexpr uintptr_t OFF_PLAYER_CORRECT_POS = 0x59C;

static std::vector<void*> g_EspPlayers;
static std::mutex g_EspMutex;


struct Vector3 {
  float x;
  float y;
  float z;
};

struct ObscuredIntAB_Native {
  int hvh;
  int hvl;
  int fakeValue;
};


static Vector3 Vec3(float x, float y, float z) {
  Vector3 v{x, y, z};
  return v;
}


struct EspScreenCache {
  void* player;
  ImVec2 foot2d;
  ImVec2 head2d;
  Vector3 foot3d;
  int hp;
  float lastGoodTime;
  bool valid;
};

static std::vector<EspScreenCache> g_EspScreenCache;

static ImVec2 LerpImVec2(ImVec2 a, ImVec2 b, float t) {
  return ImVec2(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t);
}

static float DistSqImVec2(ImVec2 a, ImVec2 b) {
  float dx = a.x - b.x;
  float dy = a.y - b.y;
  return dx * dx + dy * dy;
}

static EspScreenCache* GetEspCache(void* player) {
  for (auto& c : g_EspScreenCache) {
    if (c.player == player) return &c;
  }

  if (g_EspScreenCache.size() > 96) {
    g_EspScreenCache.erase(g_EspScreenCache.begin());
  }

  g_EspScreenCache.push_back({player, ImVec2(0, 0), ImVec2(0, 0), Vec3(0, 0, 0), -1, 0.0f, false});
  return &g_EspScreenCache.back();
}

static void PruneEspCache(float now) {
  g_EspScreenCache.erase(
    std::remove_if(g_EspScreenCache.begin(), g_EspScreenCache.end(),
      [now](const EspScreenCache& c) {
        return !c.player || (c.valid && (now - c.lastGoodTime) > 5.0f);
      }),
    g_EspScreenCache.end()
  );
}


static Vector3 Add(Vector3 a, Vector3 b) {
  return Vec3(a.x + b.x, a.y + b.y, a.z + b.z);
}

static Vector3 Scale(Vector3 v, float s) {
  return Vec3(v.x * s, v.y * s, v.z * s);
}

static float Len(Vector3 v) {
  return sqrtf(v.x * v.x + v.y * v.y + v.z * v.z);
}

static Vector3 Normalize(Vector3 v) {
  float l = Len(v);
  if (l < 0.0001f) return Vec3(0.0f, 0.0f, 0.0f);
  return Scale(v, 1.0f / l);
}

template <typename T>
static inline T& Field(void* instance, uintptr_t offset) {
  return *reinterpret_cast<T*>(reinterpret_cast<uintptr_t>(instance) + offset);
}

// IL2CPP function pointers resolved at runtime.
static bool    (*Player_get_islocal)(void* instance) = nullptr;
static int     (*Player_getTeam)(void* instance) = nullptr;
static void    (*orig_Player_Update)(void* instance) = nullptr;
static void    (*orig_Player_LateUpdate)(void* instance) = nullptr;
static void    (*orig_Player_Start)(void* instance) = nullptr;
static void    (*orig_Player_Init)(void* instance) = nullptr;
static void*   (*Component_get_transform)(void* instance) = nullptr;
static Vector3 (*Transform_get_position)(void* transform) = nullptr;
static void    (*Transform_set_position)(void* transform, Vector3 value) = nullptr;
static Vector3 (*Transform_get_forward)(void* transform) = nullptr;
static Vector3 (*Transform_get_right)(void* transform) = nullptr;
static float   (*Time_get_deltaTime)() = nullptr;
static Vector3 (*Camera_WorldToScreenPoint)(void* camera, Vector3 position) = nullptr;
static void*   (*Camera_get_main)() = nullptr;
static void*   (*Camera_get_current)() = nullptr;
static float   (*Player_get_height)(void* instance) = nullptr;
static float   (*Player_get_headHeight)(void* instance) = nullptr;
static void    (*orig_Player_OnDestroy)(void* instance) = nullptr;

// CTF ACMON bypass hooks.
// These are intentionally narrow: they only target the mock ACMON/ban path visible
// in the supplied dump.cs, instead of trying to hide the loader or defeat generic protections.
static void (*orig_ACMON_SlowUpdate)(void* instance) = nullptr;
static void (*orig_ACMON_MyUpdate)(void* instance) = nullptr;
static void (*orig_ACMON_StaticUpdate)() = nullptr;
static void (*orig_Kube_Ban)(int reason) = nullptr;
static bool (*orig_Kube_IsBanned)(void* photonPlayer) = nullptr;
static void (*orig_ObjectsHolder_Banned)(void* instance, int reason) = nullptr;

static void hook_ACMON_SlowUpdate(void* instance) {
  if (AntiCheatBypass) return;
  if (orig_ACMON_SlowUpdate) orig_ACMON_SlowUpdate(instance);
}

static void hook_ACMON_MyUpdate(void* instance) {
  if (AntiCheatBypass) return;
  if (orig_ACMON_MyUpdate) orig_ACMON_MyUpdate(instance);
}

static void hook_ACMON_StaticUpdate() {
  if (AntiCheatBypass) return;
  if (orig_ACMON_StaticUpdate) orig_ACMON_StaticUpdate();
}

static void hook_Kube_Ban(int reason) {
  if (AntiCheatBypass) {
    LOGD("CTF ACMON bypass blocked kube.Kube::Ban reason=%d", reason);
    return;
  }
  if (orig_Kube_Ban) orig_Kube_Ban(reason);
}

static bool hook_Kube_IsBanned(void* photonPlayer) {
  if (AntiCheatBypass) return false;
  return orig_Kube_IsBanned ? orig_Kube_IsBanned(photonPlayer) : false;
}

static void hook_ObjectsHolder_Banned(void* instance, int reason) {
  if (AntiCheatBypass) {
    LOGD("CTF ACMON bypass blocked ObjectsHolderScript::Banned reason=%d", reason);
    return;
  }
  if (orig_ObjectsHolder_Banned) orig_ObjectsHolder_Banned(instance, reason);
}

static void HookVoid(const char* label, void* target, void* replace, void** original) {
  if (!target) {
    LOGD("%s not found", label);
    return;
  }
  if (DobbyHook(target, replace, original) == 0) {
    LOGD("%s hooked", label);
  } else {
    LOGD("%s hook failed", label);
  }
}


static int ReadPlayerHealth(void* player) {
  if (!player) return -1;

  ObscuredIntAB_Native h = Field<ObscuredIntAB_Native>(player, OFF_PLAYER_HEALTH);

  // In this build ObscuredIntAB keeps a fakeValue mirror. It is enough for ESP bars,
  // and avoids calling the value-type op_Implicit ABI every render tick.
  if (h.fakeValue >= 0 && h.fakeValue <= 500) return h.fakeValue;

  // Fallback heuristic for noisy builds: split hidden halves sometimes xor back into
  // the clear value. If not plausible, return unknown (-1).
  int guess = h.hvh ^ h.hvl;
  if (guess >= 0 && guess <= 500) return guess;

  return -1;
}

static bool IsPlayerInitialized(void* player) {
  if (!player) return false;
  return Field<bool>(player, OFF_PLAYER_INITIALIZED);
}

static bool IsSaneWorldPos(Vector3 v) {
  if (!std::isfinite(v.x) || !std::isfinite(v.y) || !std::isfinite(v.z)) return false;
  if (fabsf(v.x) > 10000.0f || fabsf(v.y) > 10000.0f || fabsf(v.z) > 10000.0f) return false;
  // Network-corrected position can be zero before the first sync packet. Treat exact
  // zero as invalid for remote ESP, otherwise many boxes collapse at map origin.
  if (fabsf(v.x) < 0.001f && fabsf(v.y) < 0.001f && fabsf(v.z) < 0.001f) return false;
  return true;
}

static bool GetNetworkCorrectedPosition(void* player, Vector3& out) {
  if (!player) return false;
  out = Field<Vector3>(player, OFF_PLAYER_CORRECT_POS);
  return IsSaneWorldPos(out);
}

static int ReadPlayerTeam(void* player) {
  if (!player) return -9999;

  if (Player_getTeam) {
    int t = Player_getTeam(player);
    if (t > -100 && t < 100) return t;
  }

  int raw = Field<int>(player, OFF_PLAYER_TEAM);
  if (raw > -100 && raw < 100) return raw;

  return -9999;
}

static bool ShouldDrawByTeam(void* player, int localTeam) {
  if (!EspTeamCheck) return true;
  if (!player || localTeam == -9999) return true;

  int team = ReadPlayerTeam(player);
  if (team == -9999) return true;

  bool sameTeam = (team == localTeam);

  // The user's current CTF run showed the filter inverted: allies were drawn and
  // enemies were hidden. This toggle flips the comparison without touching offsets.
  if (EspInvertTeamLogic) {
    sameTeam = !sameTeam;
  }

  // Enemy-only filter: skip whoever is considered same-team after calibration.
  return !sameTeam;
}

static void EspTrackPlayer(void* player) {
  if (!player) return;

  std::lock_guard<std::mutex> lock(g_EspMutex);
  if (std::find(g_EspPlayers.begin(), g_EspPlayers.end(), player) == g_EspPlayers.end()) {
    if (g_EspPlayers.size() > 64) {
      g_EspPlayers.erase(g_EspPlayers.begin());
    }
    g_EspPlayers.push_back(player);
  }
}

static void EspRemovePlayer(void* player) {
  if (!player) return;

  std::lock_guard<std::mutex> lock(g_EspMutex);
  g_EspPlayers.erase(std::remove(g_EspPlayers.begin(), g_EspPlayers.end(), player), g_EspPlayers.end());
  if (g_LocalPlayer == player) {
    g_LocalPlayer = nullptr;
  }
}

static size_t EspPlayerCount() {
  std::lock_guard<std::mutex> lock(g_EspMutex);
  return g_EspPlayers.size();
}

static bool GetComponentWorldPosition(void* component, Vector3& out) {
  if (!component || !Component_get_transform || !Transform_get_position) return false;

  void* tr = Component_get_transform(component);
  if (!tr) return false;

  out = Transform_get_position(tr);
  if (!std::isfinite(out.x) || !std::isfinite(out.y) || !std::isfinite(out.z)) return false;
  return true;
}

static bool GetPlayerBodyPosition(void* player, Vector3& out) {
  if (!player) return false;

  // Wall ESP default: use network-corrected position first for remote players. This
  // remains valid behind walls/objects, while Renderer/skin/head transforms can be
  // culled or temporarily not updated by the client.
  if (EspWallMode && EspUseNetworkPos && player != g_LocalPlayer) {
    if (GetNetworkCorrectedPosition(player, out)) {
      return true;
    }
  }

  // CharacterController is usually the visible capsule and works well when the remote
  // player object is fully active.
  if (EspUseControllerPos) {
    void* controller = Field<void*>(player, OFF_PLAYER_CONTROLLER);
    if (GetComponentWorldPosition(controller, out) && IsSaneWorldPos(out)) {
      return true;
    }
  }

  if (GetComponentWorldPosition(player, out) && IsSaneWorldPos(out)) {
    return true;
  }

  // Last fallback: network-corrected position.
  return GetNetworkCorrectedPosition(player, out);
}

static bool GetPlayerHeadPosition(void* player, const Vector3& body, Vector3& head) {
  if (!player) return false;

  // In wall mode we deliberately avoid Renderer/head transforms. Those were the cause
  // of boxes disappearing behind map objects in the user's test.
  if (!EspWallMode && EspUseHeadRenderer) {
    void* headRenderer = Field<void*>(player, OFF_PLAYER_HEAD_RENDER);
    if (GetComponentWorldPosition(headRenderer, head) && IsSaneWorldPos(head)) {
      return true;
    }

    void* skinRenderer = Field<void*>(player, OFF_PLAYER_SKIN);
    if (GetComponentWorldPosition(skinRenderer, head) && IsSaneWorldPos(head)) {
      head.y += 0.55f;
      return true;
    }
  }

  head = body;

  float height = 1.80f;
  if (Player_get_headHeight) {
    float hh = Player_get_headHeight(player);
    if (std::isfinite(hh) && hh > 0.2f && hh < 4.0f) {
      height = hh;
    }
  } else if (Player_get_height) {
    float h = Player_get_height(player);
    if (std::isfinite(h) && h > 0.8f && h < 4.0f) {
      height = h;
    }
  }

  head.y += height + EspHeightOffset;
  return IsSaneWorldPos(head);
}

static void* GetEspCamera() {
  // Use the real scene camera for projection. cameraComp inside PlayerScript is good
  // for movement direction, but not always the Camera instance used by the current view.
  if (EspUseMainCamera && Camera_get_main) {
    void* cam = Camera_get_main();
    if (cam) return cam;
  }

  if (Camera_get_current) {
    void* cam = Camera_get_current();
    if (cam) return cam;
  }

  if (g_LocalPlayer) {
    void* cam = Field<void*>(g_LocalPlayer, OFF_PLAYER_CAMERA);
    if (cam) return cam;
  }

  return nullptr;
}

static bool CTFWorldToScreen(Vector3 world, ImVec2& screen, float& depth) {
  if (!Camera_WorldToScreenPoint) return false;

  void* camera = GetEspCamera();
  if (!camera) return false;

  Vector3 sp = Camera_WorldToScreenPoint(camera, world);
  depth = sp.z;
  if (!std::isfinite(sp.x) || !std::isfinite(sp.y) || !std::isfinite(sp.z)) return false;
  if (sp.z <= 0.10f) return false;

  ImVec2 display = ImGui::GetIO().DisplaySize;
  screen.x = sp.x;
  screen.y = EspFlipY ? (display.y - sp.y) : sp.y;

  // Keep a small tolerance so boxes at the edge do not flicker too much.
  return screen.x > -250.0f && screen.x < display.x + 250.0f &&
         screen.y > -250.0f && screen.y < display.y + 250.0f;
}

static float Distance3D(Vector3 a, Vector3 b) {
  return sqrtf((a.x - b.x) * (a.x - b.x) +
               (a.y - b.y) * (a.y - b.y) +
               (a.z - b.z) * (a.z - b.z));
}

static void DrawESPOverlay() {
  if (!EspEnable || !g_LocalPlayer || !Component_get_transform || !Transform_get_position || !Camera_WorldToScreenPoint) {
    return;
  }

  std::vector<void*> players;
  {
    std::lock_guard<std::mutex> lock(g_EspMutex);
    players = g_EspPlayers;
  }

  ImDrawList* draw = ImGui::GetBackgroundDrawList();
  ImVec2 display = ImGui::GetIO().DisplaySize;
  float now = (float)ImGui::GetTime();

  int localTeam = -9999;
  Vector3 localPos = Vec3(0.0f, 0.0f, 0.0f);

  if (g_LocalPlayer) {
    localTeam = ReadPlayerTeam(g_LocalPlayer);
    GetPlayerBodyPosition(g_LocalPlayer, localPos);
  }

  g_EspRendered = 0;
  g_EspSkippedTeam = 0;
  g_EspSkippedPos = 0;
  g_EspSkippedW2S = 0;
  g_EspLocalTeamDbg = localTeam;

  int rendered = 0;

  for (void* player : players) {
    if (!player || player == g_LocalPlayer) continue;
    if (EspSkipUninitialized && !IsPlayerInitialized(player)) continue;

    if (!ShouldDrawByTeam(player, localTeam)) {
      g_EspSkippedTeam++;
      continue;
    }

    int hp = ReadPlayerHealth(player);
    if (EspSkipDead && hp == 0) continue;

    EspScreenCache* cache = GetEspCache(player);

    bool fresh = false;
    Vector3 foot = Vec3(0.0f, 0.0f, 0.0f);
    Vector3 head = Vec3(0.0f, 0.0f, 0.0f);
    ImVec2 foot2d(0, 0);
    ImVec2 head2d(0, 0);

    if (GetPlayerBodyPosition(player, foot) && GetPlayerHeadPosition(player, foot, head)) {
      float zFoot = 0.0f;
      float zHead = 0.0f;

      if (CTFWorldToScreen(foot, foot2d, zFoot) && CTFWorldToScreen(head, head2d, zHead)) {
        fresh = true;
      } else {
        g_EspSkippedW2S++;
      }
    } else {
      g_EspSkippedPos++;
    }

    if (fresh) {
      if (EspStabilize && cache && cache->valid) {
        float jump = DistSqImVec2(cache->head2d, head2d);
        float blend = jump > 90000.0f ? 1.0f : 0.42f;
        cache->head2d = LerpImVec2(cache->head2d, head2d, blend);
        cache->foot2d = LerpImVec2(cache->foot2d, foot2d, blend);
      } else if (cache) {
        cache->head2d = head2d;
        cache->foot2d = foot2d;
      }

      if (cache) {
        cache->foot3d = foot;
        cache->lastGoodTime = now;
        cache->hp = hp;
        cache->valid = true;
        head2d = cache->head2d;
        foot2d = cache->foot2d;
      }
    } else {
      if (!EspStabilize || !cache || !cache->valid || (now - cache->lastGoodTime) > EspCacheSeconds) {
        continue;
      }

      head2d = cache->head2d;
      foot2d = cache->foot2d;
      foot = cache->foot3d;
      if (hp < 0) hp = cache->hp;
    }

    if (EspDebugPoint) {
      draw->AddCircleFilled(foot2d, 4.0f, IM_COL32(255, 255, 0, 255));
      draw->AddCircleFilled(head2d, 4.0f, IM_COL32(255, 0, 0, 255));
    }

    float boxH = fabsf(foot2d.y - head2d.y);
    if (boxH < 10.0f || boxH > display.y * 1.65f) continue;

    float boxW = boxH * 0.45f;
    float x = head2d.x - boxW * 0.5f;
    float y = head2d.y;

    float hpForBar = (hp < 0) ? EspMaxHealth : (float)hp;
    float hpFrac = hpForBar / EspMaxHealth;
    if (hpFrac < 0.0f) hpFrac = 0.0f;
    if (hpFrac > 1.0f) hpFrac = 1.0f;

    ImU32 mainColor = IM_COL32(60, 255, 120, 255);
    ImU32 outlineColor = IM_COL32(0, 0, 0, 180);
    ImU32 healthBg = IM_COL32(0, 0, 0, 180);
    ImU32 healthFill = hpFrac > 0.55f ? IM_COL32(60, 255, 90, 255) :
                       hpFrac > 0.25f ? IM_COL32(255, 220, 60, 255) :
                                         IM_COL32(255, 70, 70, 255);
    ImU32 textColor = IM_COL32(255, 255, 255, 255);

    if (EspLine) {
      ImVec2 lineStart(display.x * 0.5f, display.y - 8.0f);
      draw->AddLine(lineStart, ImVec2(head2d.x, head2d.y), outlineColor, EspLineThickness + 2.0f);
      draw->AddLine(lineStart, ImVec2(head2d.x, head2d.y), mainColor, EspLineThickness);
    }

    if (EspBox) {
      ImVec2 a(x, y);
      ImVec2 b(x + boxW, y + boxH);
      draw->AddRect(ImVec2(a.x - 1.0f, a.y - 1.0f), ImVec2(b.x + 1.0f, b.y + 1.0f), outlineColor, 0.0f, 0, EspBoxThickness + 2.0f);
      draw->AddRect(a, b, mainColor, 0.0f, 0, EspBoxThickness);
    }

    if (EspHealth) {
      float barW = 5.0f;
      float barX = x - 10.0f;
      float barY = y;
      float fillH = boxH * hpFrac;

      draw->AddRectFilled(ImVec2(barX, barY), ImVec2(barX + barW, barY + boxH), healthBg, 0.0f);
      draw->AddRectFilled(ImVec2(barX, barY + boxH - fillH), ImVec2(barX + barW, barY + boxH), healthFill, 0.0f);
      draw->AddRect(ImVec2(barX, barY), ImVec2(barX + barW, barY + boxH), outlineColor, 0.0f, 0, 1.5f);
    }

    if (EspDistance) {
      float meters = Distance3D(localPos, foot);
      char distText[32];
      snprintf(distText, sizeof(distText), "%.0fm", meters);
      draw->AddText(ImVec2(x, y + boxH + 5.0f), textColor, distText);
    }

    rendered++;
    g_EspRendered = rendered;
    if (rendered >= 64) break;
  }

  PruneEspCache(now);
}


static void hook_Player_OnDestroy(void* instance) {
  EspRemovePlayer(instance);
  if (orig_Player_OnDestroy) {
    orig_Player_OnDestroy(instance);
  }
}

static void TrackPlayerAndLocal(void* instance) {
  if (!instance) return;

  EspTrackPlayer(instance);

  if (Player_get_islocal && Player_get_islocal(instance)) {
    g_LocalPlayer = instance;
  }
}

static void hook_Player_Start(void* instance) {
  TrackPlayerAndLocal(instance);
  if (orig_Player_Start) {
    orig_Player_Start(instance);
  }
  TrackPlayerAndLocal(instance);
}

static void hook_Player_Init(void* instance) {
  TrackPlayerAndLocal(instance);
  if (orig_Player_Init) {
    orig_Player_Init(instance);
  }
  TrackPlayerAndLocal(instance);
}

static void hook_Player_LateUpdate(void* instance) {
  TrackPlayerAndLocal(instance);
  if (orig_Player_LateUpdate) {
    orig_Player_LateUpdate(instance);
  }
}

// IMPORTANT:
// The previous "hard noclip" used CharacterController.set_detectCollisions(false).
// In this CTF build that flips the game's ACMOn_noclip check immediately.
// SafePhase keeps Unity collision flags untouched and only uses the same Transform
// movement path that already works for Fly.
static void ApplyNoClip(void* player, bool enabled) {
  if (!player || !enabled) return;

  Field<bool>(player, OFF_PLAYER_GROUNDED) = true;
  Field<Vector3>(player, OFF_PLAYER_MOVEDIR) = Vec3(0.0f, 0.0f, 0.0f);
}

static void ApplyFlyOrPhase(void* player, bool allowVertical) {
  if (!player || !Component_get_transform || !Transform_get_position || !Transform_set_position) return;

  float dt = Time_get_deltaTime ? Time_get_deltaTime() : 0.016f;
  if (dt <= 0.0f || dt > 0.2f) dt = 0.016f;

  void* playerTransform = Component_get_transform(player);
  if (!playerTransform) return;

  Vector3 forward = Vec3(0.0f, 0.0f, 1.0f);
  Vector3 right = Vec3(1.0f, 0.0f, 0.0f);

  void* camera = Field<void*>(player, OFF_PLAYER_CAMERA);
  if (camera && Transform_get_forward && Transform_get_right) {
    void* cameraTransform = Component_get_transform(camera);
    if (cameraTransform) {
      forward = Transform_get_forward(cameraTransform);
      right = Transform_get_right(cameraTransform);
    }
  }

  Vector3 direction = Vec3(0.0f, 0.0f, 0.0f);

  if (Field<bool>(player, OFF_CTRL_FORWARD))  direction = Add(direction, forward);
  if (Field<bool>(player, OFF_CTRL_BACKWARD)) direction = Add(direction, Scale(forward, -1.0f));
  if (Field<bool>(player, OFF_CTRL_RIGHT))    direction = Add(direction, right);
  if (Field<bool>(player, OFF_CTRL_LEFT))     direction = Add(direction, Scale(right, -1.0f));
  if (allowVertical && Field<bool>(player, OFF_CTRL_JUMP)) direction = Add(direction, Vec3(0.0f, 1.0f, 0.0f));
  if (allowVertical && Field<bool>(player, OFF_CTRL_DOWN)) direction = Add(direction, Vec3(0.0f, -1.0f, 0.0f));

  // Phase mode on the ground should not inherit camera pitch; otherwise looking up/down
  // can act like fly. Keep Y locked unless Fly is enabled.
  if (!allowVertical) {
    direction.y = 0.0f;
  }

  if (Len(direction) < 0.0001f) return;

  Vector3 pos = Transform_get_position(playerTransform);
  pos = Add(pos, Scale(Normalize(direction), FlySpeed * dt));
  Transform_set_position(playerTransform, pos);

  Field<bool>(player, OFF_PLAYER_GROUNDED) = true;
  Field<Vector3>(player, OFF_PLAYER_MOVEDIR) = Vec3(0.0f, 0.0f, 0.0f);
}

static void hook_Player_Update(void* instance) {
  EspTrackPlayer(instance);

  bool isLocal = false;

  if (instance && Player_get_islocal) {
    isLocal = Player_get_islocal(instance);
  }

  if (isLocal) {
    g_LocalPlayer = instance;
    if (NoClipHack || FlyHack) {
      ApplyNoClip(instance, NoClipHack);
    }
  }

  if (orig_Player_Update) {
    orig_Player_Update(instance);
  }

  if (isLocal) {
    if (NoClipHack || FlyHack) {
      ApplyNoClip(instance, NoClipHack);
    }
    if (FlyHack || NoClipHack) {
      ApplyFlyOrPhase(instance, FlyHack);
    }
  }
}

void hack();
void writeLog(const std::string& logMessage, const std::string& filename = "/storage/emulated/0/Android/data/com.Nobodyshot.kuboom/files/log.txt");

class MyModule : public zygisk::ModuleBase {
public:
    void onLoad(Api *api, JNIEnv *env) override {
        this->api_ = api;
        this->env_ = env;
    }

    void preAppSpecialize(AppSpecializeArgs *args) override {
        const char *process = env_->GetStringUTFChars(args->nice_name, nullptr);
        LOGD("zygisk preAppSpecialize process=%s; package gate disabled", process ? process : "null");

        // Loader/CTF mode: do not filter by package name.
        // This avoids startup being skipped when the actual process name is different.
        is_game_ = true;

        env_->ReleaseStringUTFChars(args->nice_name, process);
    }

    void postAppSpecialize(const AppSpecializeArgs *args) override {
        if (is_game_) {
            std::thread{hack}.detach();
        }
    }

private:
    Api *api_ = nullptr;
    JNIEnv *env_ = nullptr;
    bool is_game_ = false;
};


uintptr_t il2cpp_base = 0;
void *getRealAddr(ulong offset) {
  return reinterpret_cast<void*>(il2cpp_base + offset);
};


bool clearMousePos = true;
bool ImGuiOK = false;
static bool g_Il2CppInputReady = false;

void SetupImgui() {
  IMGUI_CHECKVERSION();
  ImGui::CreateContext();
  ImGui_ImplAndroid_Init(nullptr);

  ImGuiIO& io = ImGui::GetIO();
  ImGuiOK = true;
  io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
  io.IniFilename = nullptr;

  ImGui::StyleColorsClassic();

  ImGuiStyle& style = ImGui::GetStyle();
  style.WindowTitleAlign = ImVec2(0.0f, 0.5f);
  style.WindowRounding = 0.0f;
  style.ChildRounding = 0.0f;
  style.FrameRounding = 0.0f;
  style.PopupRounding = 0.0f;
  style.ScrollbarRounding = 0.0f;
  style.GrabRounding = 0.0f;
  style.TabRounding = 0.0f;
  style.WindowBorderSize = 1.0f;
  style.ChildBorderSize = 1.0f;
  style.FrameBorderSize = 1.0f;
  style.ScrollbarSize = 36.0f;
  style.GrabMinSize = 22.0f;
  style.WindowPadding = ImVec2(10.0f, 10.0f);
  style.FramePadding = ImVec2(8.0f, 6.0f);
  style.ItemSpacing = ImVec2(8.0f, 7.0f);

  ImFontConfig font_cfg;
  font_cfg.SizePixels = 34.0f;
  static const ImWchar ranges[] = {
    0x0020, 0x00FF,
    0x0100, 0x024F,
    0x0400, 0x052F,
    0
  };

  io.Fonts->AddFontFromMemoryTTF(Roboto_Regular, sizeof(Roboto_Regular), 34.0f, &font_cfg, ranges);

  ImGui_ImplOpenGL3_Init("#version 100");
}


struct UnityEngine_Vector2_Fields {
  float x;
  float y;
};

struct UnityEngine_Vector2_o {
  UnityEngine_Vector2_Fields fields;
};

enum TouchPhase {
  Began = 0,
  Moved = 1,
  Stationary = 2,
  Ended = 3,
  Canceled = 4
};

struct UnityEngine_Touch_Fields {
  int32_t m_FingerId;
  struct UnityEngine_Vector2_o m_Position;
  struct UnityEngine_Vector2_o m_RawPosition;
  struct UnityEngine_Vector2_o m_PositionDelta;
  float m_TimeDelta;
  int32_t m_TapCount;
  int32_t m_Phase;
  int32_t m_Type;
  float m_Pressure;
  float m_maximumPossiblePressure;
  float m_Radius;
  float m_RadiusVariance;
  float m_AltitudeAngle;
  float m_AzimuthAngle;
};



struct Point {
  ImVec2 position;
  ImVec2 velocity;
  float radius;
};

static std::vector < Point > points;

float randomFloat(float min, float max) {
  return min + (rand() / (float)RAND_MAX) * (max - min);
}

void BackGroundDots(int numberOfDots) {
  ImDrawList* draw_list = ImGui::GetWindowDrawList();
  ImVec2 windowSize = ImGui::GetIO().DisplaySize;

  // Время для движения и цвета
  static auto lastTime = std::chrono::high_resolution_clock::now();
  auto currentTime = std::chrono::high_resolution_clock::now();
  std::chrono::duration < float > deltaTime = currentTime - lastTime;
  lastTime = currentTime;
  float t = std::chrono::duration < float > (currentTime.time_since_epoch()).count();

  // Удаляем точки вне экрана
  points.erase(std::remove_if(points.begin(), points.end(), [&](const Point& p) {
    return (p.position.x < 0 - p.radius || p.position.x > windowSize.x + p.radius ||
      p.position.y < 0 - p.radius || p.position.y > windowSize.y + p.radius);
  }), points.end());

  // Добавляем новые точки
  while (points.size() < numberOfDots) {
    Point newPoint;
    newPoint.position.x = randomFloat(0, windowSize.x);
    newPoint.position.y = randomFloat(0, windowSize.y);
    newPoint.velocity.x = randomFloat(-30.0f, 30.0f);
    newPoint.velocity.y = randomFloat(-30.0f, 30.0f);
    newPoint.radius = randomFloat(2.0f, 4.0f);
    points.push_back(newPoint);
  }

  // Обновление и отрисовка точек
  for (int i = 0; i < points.size(); ++i) {
    // Движение точки
    points[i].position.x += points[i].velocity.x * deltaTime.count();
    points[i].position.y += points[i].velocity.y * deltaTime.count();

    // Отскок от границ
    if (points[i].position.x < 0) {
      points[i].position.x = 0; points[i].velocity.x *= -1;
    }
    if (points[i].position.x > windowSize.x) {
      points[i].position.x = windowSize.x; points[i].velocity.x *= -1;
    }
    if (points[i].position.y < 0) {
      points[i].position.y = 0; points[i].velocity.y *= -1;
    }
    if (points[i].position.y > windowSize.y) {
      points[i].position.y = windowSize.y; points[i].velocity.y *= -1;
    }

    // Динамический цвет точки (циклический)
    float r = 0.3f + 0.7f * (0.5f + 0.5f * sinf(t + i));
    float g = 0.3f + 0.7f * (0.5f + 0.5f * sinf(t + i + 2.0f));
    float b = 0.3f + 0.7f * (0.5f + 0.5f * sinf(t + i + 4.0f));
    ImVec4 dotColor = ImVec4(r, g, b, 0.8f);

    // Соединение с другими точками
    float maxDist = 60.0f;
    for (int j = i + 1; j < points.size(); ++j) {
      float dx = points[i].position.x - points[j].position.x;
      float dy = points[i].position.y - points[j].position.y;
      float dist2 = dx*dx + dy*dy;
      if (dist2 < maxDist*maxDist) {
        float alpha = 2.0f - (sqrtf(dist2) / maxDist);
        ImVec4 lineColor = ImVec4(0.2f, 0.2f, 0.3f, alpha * 0.7f);
        draw_list->AddLine(points[i].position, points[j].position, ImGui::ColorConvertFloat4ToU32(lineColor), 1.0f);
      }
    }

    // Отрисовка самой точки
    draw_list->AddCircleFilled(points[i].position, points[i].radius, ImGui::ColorConvertFloat4ToU32(dotColor));
  }
}


ImVec4 HSVtoRGB(float h, float s, float v) {
  float r,
  g,
  b;

  int i = int(h * 6.0f);
  float f = h * 6.0f - i;
  float p = v * (1.0f - s);
  float q = v * (1.0f - f * s);
  float t = v * (1.0f - (1.0f - f) * s);

  switch (i % 6) {
    case 0: r = v; g = t; b = p; break;
    case 1: r = q; g = v; b = p; break;
    case 2: r = p; g = v; b = t; break;
    case 3: r = p; g = q; b = v; break;
    case 4: r = t; g = p; b = v; break;
    case 5: r = v; g = p; b = q; break;
  }

  return ImVec4(r, g, b, 1.0f);
}

#include <ctime>
#include <cstdio>

time_t GetExpiryTimestamp(const char* expiry_date_str) {
    // expiry_date_str format is "DD-MM-YY"
    struct tm expiry_tm = {0};
    int day, month, year;
    if (sscanf(expiry_date_str, "%d-%d-%d", &day, &month, &year) != 3) {
        return 0; // invalid format fallback, never expires
    }
    expiry_tm.tm_mday = day;
    expiry_tm.tm_mon = month - 1; // tm_mon is 0-11
    expiry_tm.tm_year = (year < 100) ? (year + 100) : year; // 2000-based year (e.g., 25 -> 2025)
    expiry_tm.tm_hour = 0;
    expiry_tm.tm_min = 0;
    expiry_tm.tm_sec = 0;
    expiry_tm.tm_isdst = -1; // let system determine
    return mktime(&expiry_tm);
}

// Global toggle
static bool g_ShowMenu = true;

inline ImVec2 operator*(const ImVec2& v, float s) {
  return ImVec2(v.x * s, v.y * s);
}

void DrawLogo() {
  if (!ImGuiOK) return;

  ImGui::SetNextWindowPos(ImVec2(160, 180), ImGuiCond_FirstUseEver);

  ImGuiWindowFlags flags = ImGuiWindowFlags_NoSavedSettings |
                           ImGuiWindowFlags_AlwaysAutoResize |
                           ImGuiWindowFlags_NoTitleBar |
                           ImGuiWindowFlags_NoBackground;

  ImGui::Begin("MenuToggle", nullptr, flags);

  ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(18, 14));
  if (ImGui::Button("MENU")) {
    g_ShowMenu = !g_ShowMenu;
  }
  ImGui::PopStyleVar();

  ImGui::End();
}

void DrawMenu() {
  if (!g_ShowMenu) return;

  ImGui::SetNextWindowPos(ImVec2(80, 90), ImGuiCond_FirstUseEver);
  ImGui::SetNextWindowSize(ImVec2(620, 540), ImGuiCond_FirstUseEver);

  ImGuiWindowFlags flags = ImGuiWindowFlags_NoCollapse |
                           ImGuiWindowFlags_NoSavedSettings;

  if (!ImGui::Begin("Shattered Engine", &g_ShowMenu, flags)) {
    ImGui::End();
    return;
  }

  if (ImGui::BeginTabBar("tabs")) {
    if (ImGui::BeginTabItem("Move")) {
      ImGui::Checkbox("Fly", &FlyHack);
      ImGui::Checkbox("NoClip", &NoClipHack);
      ImGui::Checkbox("Bypass", &AntiCheatBypass);
      ImGui::SliderFloat("Speed", &FlySpeed, 1.0f, 40.0f, "%.1f");
      ImGui::EndTabItem();
    }

    if (ImGui::BeginTabItem("ESP")) {
      ImGui::Checkbox("Enable", &EspEnable);
      ImGui::Checkbox("Line", &EspLine);
      ImGui::Checkbox("Box", &EspBox);
      ImGui::Checkbox("Health", &EspHealth);
      ImGui::Checkbox("Distance", &EspDistance);
      ImGui::Checkbox("Team", &EspTeamCheck);
      ImGui::Checkbox("Invert Team", &EspInvertTeamLogic);
      ImGui::Checkbox("Wall", &EspWallMode);
      ImGui::Checkbox("Stabilize", &EspStabilize);
      ImGui::Checkbox("Skip Dead", &EspSkipDead);
      ImGui::SliderFloat("Cache", &EspCacheSeconds, 0.20f, 2.50f, "%.2f");
      ImGui::SliderFloat("Height", &EspHeightOffset, -0.80f, 0.80f, "%.2f");
      ImGui::SliderFloat("Max HP", &EspMaxHealth, 1.0f, 300.0f, "%.0f");
      ImGui::SliderFloat("Line Size", &EspLineThickness, 1.0f, 6.0f, "%.1f");
      ImGui::SliderFloat("Box Size", &EspBoxThickness, 1.0f, 6.0f, "%.1f");
      ImGui::EndTabItem();
    }

    if (ImGui::BeginTabItem("Info")) {
      ImGui::Text("Players: %zu", EspPlayerCount());
      ImGui::Text("Rendered: %d", g_EspRendered);
      ImGui::Text("Local: %p", g_LocalPlayer);
      ImGui::Text("Team: %d", g_EspLocalTeamDbg);
      ImGui::EndTabItem();
    }

    ImGui::EndTabBar();
  }

  ImGui::End();
}





// ---------------- Android native input hook ----------------
// Some Unity/loader combinations render ImGui correctly but never feed UnityEngine.Input
// into the injected library. Hooking AInputQueue_getEvent lets ImGui receive the same
// touch events as the game without depending on IL2CPP input methods.
static int32_t (*old_AInputQueue_getEvent)(AInputQueue* queue, AInputEvent** outEvent) = nullptr;
static bool g_InputHookInstalled = false;
static bool g_NativeInputSeen = false;

static int32_t hook_AInputQueue_getEvent(AInputQueue* queue, AInputEvent** outEvent) {
  int32_t result = old_AInputQueue_getEvent ? old_AInputQueue_getEvent(queue, outEvent) : -1;

  if (result >= 0 && outEvent != nullptr && *outEvent != nullptr && g_IsSetup) {
    ImGui_ImplAndroid_HandleInputEvent(*outEvent);
    if (!g_NativeInputSeen) {
      g_NativeInputSeen = true;
      LOGD("native AInputQueue event reached ImGui");
    }
  }

  return result;
}

static void* ResolveLibAndroidSymbol(const char* symbol) {
  void* sym = DobbySymbolResolver("/system/lib64/libandroid.so", symbol);
  if (!sym) sym = DobbySymbolResolver("/system/lib/libandroid.so", symbol);
  if (!sym) sym = DobbySymbolResolver("libandroid.so", symbol);
  if (!sym) sym = DobbySymbolResolver(nullptr, symbol);

  if (!sym) {
    void* handle = dlopen("libandroid.so", RTLD_NOW);
    if (handle) sym = dlsym(handle, symbol);
  }

  return sym;
}

static void HookNativeInput() {
  if (g_InputHookInstalled) return;

  void* fn = ResolveLibAndroidSymbol("AInputQueue_getEvent");
  if (!fn) {
    LOGD("AInputQueue_getEvent not found; using Unity Input fallback only");
    return;
  }

  if (DobbyHook(fn, (void*)hook_AInputQueue_getEvent, (void**)&old_AInputQueue_getEvent) == 0) {
    g_InputHookInstalled = true;
    LOGD("AInputQueue_getEvent hooked for ImGui touch input");
  } else {
    LOGD("DobbyHook AInputQueue_getEvent failed");
  }
}

inline EGLBoolean (*old_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
inline EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {

  eglQuerySurface(dpy, surface, EGL_WIDTH, &g_GlWidth);
  eglQuerySurface(dpy, surface, EGL_HEIGHT, &g_GlHeight);
  
  static bool should_clear_mouse_pos = false;

  if (!g_IsSetup) {
    LOGD("ImGui setup on first frame: %dx%d", g_GlWidth, g_GlHeight);
    prevWidth = g_GlWidth;
    prevHeight = g_GlHeight;
    SetupImgui();

    g_IsSetup = true;
  }
  ImGuiIO &io = ImGui::GetIO();
  ImGui_ImplOpenGL3_NewFrame();
  ImGui_ImplAndroid_NewFrame(g_GlWidth, g_GlHeight);
  ImGui::NewFrame();
  // Touch input restored to the original loader path.
  // The original project clicked through UnityEngine.Input from UnityEngine.dll.
  // v9's native AInputQueue hook could mark native input as "seen" and skip this path,
  // so keep this route simple and deterministic.
  if (g_Il2CppInputReady) {
    static int (*TouchCount)(void*) = nullptr;
    static UnityEngine_Touch_Fields (*GetTouch)(int) = nullptr;
    static bool triedResolveInput = false;

    if (!triedResolveInput) {
      triedResolveInput = true;

      // Original working loader path.
      TouchCount = (int (*)(void*)) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Input", "get_touchCount", 0);
      GetTouch = (UnityEngine_Touch_Fields (*)(int)) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Input", "GetTouch", 1);

      // Fallback for newer Unity builds.
      if (!TouchCount) {
        TouchCount = (int (*)(void*)) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Input", "get_touchCount", 0);
      }
      if (!GetTouch) {
        GetTouch = (UnityEngine_Touch_Fields (*)(int)) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Input", "GetTouch", 1);
      }

      LOGD("Unity Input resolve: TouchCount=%p GetTouch=%p", (void*)TouchCount, (void*)GetTouch);
    }

    int touchCount = TouchCount ? TouchCount(nullptr) : 0;
    if (touchCount > 0 && GetTouch) {
      UnityEngine_Touch_Fields touch = GetTouch(0);
      float reverseY = io.DisplaySize.y - touch.m_Position.fields.y;

      switch (touch.m_Phase) {
        case TouchPhase::Began:
        case TouchPhase::Stationary:
          io.MousePos = ImVec2(touch.m_Position.fields.x, reverseY);
          io.MouseDown[0] = true;
          break;
        case TouchPhase::Ended:
        case TouchPhase::Canceled:
          io.MouseDown[0] = false;
          should_clear_mouse_pos = true;
          break;
        case TouchPhase::Moved:
          io.MousePos = ImVec2(touch.m_Position.fields.x, reverseY);
          break;
        default:
          break;
      }
    } else {
      io.MouseDown[0] = false;
    }
  }
  
  DrawESPOverlay();
  DrawLogo();
  DrawMenu();
  
  ImGui::Render();
  ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
  ImGui::EndFrame();
  if (should_clear_mouse_pos) {
    io.MousePos = ImVec2(-1, -1);
    should_clear_mouse_pos = false;
  }

  return old_eglSwapBuffers(dpy, surface);
}







typedef unsigned long DWORD;
static uintptr_t libBase;

uintptr_t string2Offset(const char *c) {
  int base = 16;
  // See if this function catches all possibilities.
  // If it doesn't, the function would have to be amended
  // whenever you add a combination of architecture and
  // compiler that is not yet addressed.
  static_assert(sizeof(uintptr_t) == sizeof(unsigned long) || sizeof(uintptr_t) == sizeof(unsigned long long),
    "Please add string to handle conversion for this architecture.");

  // Now choose the correct function ...
  if (sizeof(uintptr_t) == sizeof(unsigned long)) {
    return strtoul(c, nullptr, base);
  }

  // All other options exhausted, sizeof(uintptr_t) == sizeof(unsigned long long))
  return strtoull(c, nullptr, base);
}


inline void hack_injec();

static void* ResolveEglSwapBuffers() {
  void *ptr_eglSwapBuffer = nullptr;

  for (int i = 0; i < 60 && ptr_eglSwapBuffer == nullptr; ++i) {
    ptr_eglSwapBuffer = DobbySymbolResolver("/system/lib64/libEGL.so", "eglSwapBuffers");
    if (ptr_eglSwapBuffer == nullptr) {
      ptr_eglSwapBuffer = DobbySymbolResolver("/system/lib/libEGL.so", "eglSwapBuffers");
    }
    if (ptr_eglSwapBuffer == nullptr) {
      ptr_eglSwapBuffer = DobbySymbolResolver(nullptr, "eglSwapBuffers");
    }
    if (ptr_eglSwapBuffer == nullptr) {
      void* egl = dlopen("libEGL.so", RTLD_NOW);
      if (egl != nullptr) {
        ptr_eglSwapBuffer = dlsym(egl, "eglSwapBuffers");
      }
    }

    if (ptr_eglSwapBuffer == nullptr) {
      sleep(1);
    }
  }

  return ptr_eglSwapBuffer;
}

inline void StartGUI() {
  LOGD("StartGUI called");
  static bool started = false;
  if (started) return;
  started = true;

  // Original loader input path used UnityEngine.Input; do not hook AInputQueue here.

  void *ptr_eglSwapBuffer = ResolveEglSwapBuffers();
  if (ptr_eglSwapBuffer != nullptr) {
    LOGD("eglSwapBuffers resolved at %p", ptr_eglSwapBuffer);
    if (DobbyHook((void *)ptr_eglSwapBuffer, (void*)hook_eglSwapBuffers, (void**)&old_eglSwapBuffers) == 0) {
      LOGD("eglSwapBuffers hooked");
    } else {
      LOGD("DobbyHook eglSwapBuffers failed");
      return;
    }

    std::thread{hack_injec}.detach();
  } else {
    LOGD("eglSwapBuffers not found after wait");
  }
}

bool libLoaded = false;

DWORD findLibrary(const char *library) {
  char filename[0xFF] = {
    0
  },
  buffer[1024] = {
    0
  };
  FILE *fp = NULL;
  DWORD address = 0;

  sprintf(filename, OBFUSCATE("/proc/self/maps"));

  fp = fopen(filename, OBFUSCATE("rt"));
  if (fp == NULL) {
    perror(OBFUSCATE("fopen"));
    goto done;
  }

  while (fgets(buffer, sizeof(buffer), fp)) {
    if (strstr(buffer, library)) {
      address = (DWORD) strtoul(buffer, NULL, 16);
      goto done;
    }
  }

  done:

  if (fp) {
    fclose(fp);
  }

  return address;
}

DWORD getAbsoluteAddress(const char *libraryName, DWORD relativeAddr) {
  libBase = findLibrary(libraryName);
  if (libBase == 0)
  return 0;
  return (reinterpret_cast<DWORD > (libBase + relativeAddr));
}
ProcMap unityMap, anogsMap, il2cppMap;
using KittyScanner::RegisterNativeFn;

void hack() {
  LOGD("Inject Ok");
}
uintptr_t get_symbol_addr_in_pid(pid_t pid, const char* libname, uintptr_t offset_in_lib) {
  char maps_path[64];
  snprintf(maps_path, sizeof(maps_path), "/proc/%d/maps", pid);

  FILE* fp = fopen(maps_path, "r");
  if (!fp) return 0;

  char line[512];
  uintptr_t base = 0;

  while (fgets(line, sizeof(line), fp)) {
    if (strstr(line, libname)) {
      sscanf(line, "%lx-%*lx", &base);
      break;
    }
  }
  fclose(fp);

  if (base == 0) return 0;
  return base + offset_in_lib;
}

pid_t get_pid_by_name(const char* process_name) {
  DIR* proc_dir = opendir("/proc");
  if (!proc_dir) return -1;

  struct dirent* entry;
  while ((entry = readdir(proc_dir)) != NULL) {
    if (entry->d_type != DT_DIR) continue;

    pid_t pid = atoi(entry->d_name);
    if (pid <= 0) continue;

    char cmdline_path[256];
    snprintf(cmdline_path, sizeof(cmdline_path), "/proc/%d/cmdline", pid);

    FILE* fp = fopen(cmdline_path, "r");
    if (!fp) continue;

    char cmdline[256];
    fgets(cmdline, sizeof(cmdline), fp);
    fclose(fp);

    if (strstr(cmdline, process_name)) {
      closedir(proc_dir);
      return pid;
    }
  }

  closedir(proc_dir);
  return -1;
}

void writeLog(const std::string& logMessage, const std::string& filename) {
  std::ofstream outFile(filename, std::ios::app);
  if (outFile.is_open()) {
    outFile << logMessage << std::endl;
    outFile.close();
  } else {
    //std::cerr << "Log file log: << filename << std::endl;
  }
}

bool is_current_process(const char* target_name) {
  char cmdline_path[64];
  snprintf(cmdline_path, sizeof(cmdline_path), "/proc/%d/cmdline", getpid());

  FILE* fp = fopen(cmdline_path, "r");
  if (!fp) return false;

  char cmdline[256] = {
    0
  };
  fgets(cmdline, sizeof(cmdline), fp);
  fclose(fp);

  return strcmp(cmdline, target_name) == 0;
}



void hack_injec() {
  for (int i = 0; i < 90; ++i) {
    unityMap = KittyMemory::getLibraryBaseMap("libunity.so");
    il2cppMap = KittyMemory::getLibraryBaseMap("libil2cpp.so");
    if (unityMap.isValid() && il2cppMap.isValid()) break;
    sleep(1);
  }

  if (!unityMap.isValid() || !il2cppMap.isValid()) {
    LOGD("libunity/libil2cpp not ready; disabling IL2CPP hooks");
    return;
  }

  sleep(2);
  Il2CppAttach("libil2cpp.so");

  bool assembliesReady = false;
  for (int i = 0; i < 60; ++i) {
    if (Il2CppIsAssembliesLoaded()) {
      assembliesReady = true;
      break;
    }
    sleep(1);
  }

  if (!assembliesReady) {
    LOGD("IL2CPP assemblies not ready; disabling PlayerScript hook");
    return;
  }

  g_Il2CppInputReady = true;
  LOGD("IL2CPP input ready; restored UnityEngine.Input touch path enabled");

  Player_get_islocal = (bool (*)(void*)) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "PlayerScript", "get_islocal", 0);
  Player_getTeam = (int (*)(void*)) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "PlayerScript", "getTeam", 0);
  Component_get_transform = (void* (*)(void*)) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Component", "get_transform", 0);
  Transform_get_position = (Vector3 (*)(void*)) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Transform", "get_position", 0);
  Transform_set_position = (void (*)(void*, Vector3)) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Transform", "set_position", 1);
  Transform_get_forward = (Vector3 (*)(void*)) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Transform", "get_forward", 0);
  Transform_get_right = (Vector3 (*)(void*)) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Transform", "get_right", 0);
  Time_get_deltaTime = (float (*)()) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Time", "get_deltaTime", 0);
  Camera_WorldToScreenPoint = (Vector3 (*)(void*, Vector3)) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Camera", "WorldToScreenPoint", 1);
  if (!Camera_WorldToScreenPoint) {
    Camera_WorldToScreenPoint = (Vector3 (*)(void*, Vector3)) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Camera", "WorldToScreenPoint", 1);
  }
  Camera_get_main = (void* (*)()) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Camera", "get_main", 0);
  if (!Camera_get_main) {
    Camera_get_main = (void* (*)()) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Camera", "get_main", 0);
  }
  Camera_get_current = (void* (*)()) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Camera", "get_current", 0);
  if (!Camera_get_current) {
    Camera_get_current = (void* (*)()) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Camera", "get_current", 0);
  }
  Player_get_height = (float (*)(void*)) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "PlayerScript", "get_height", 0);
  Player_get_headHeight = (float (*)(void*)) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "PlayerScript", "get__headHeight", 0);
  LOGD("ESP camera/team funcs: W2S=%p main=%p current=%p getTeam=%p", (void*)Camera_WorldToScreenPoint, (void*)Camera_get_main, (void*)Camera_get_current, (void*)Player_getTeam);

  // Bypass the CTF anti-cheat monitor path that raises BanReason.ACMON_noclip.
  // From dump.cs:
  //   ACMON::SlowUpdate / MyUpdate / StaticUpdate
  //   kube.Kube::Ban(BanReason)
  //   kube.Kube::IsBanned(PhotonPlayer)
  //   ObjectsHolderScript::Banned(BanReason)
  void* acmonSlow = Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "ACMON", "SlowUpdate", 0);
  void* acmonMy = Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "ACMON", "MyUpdate", 0);
  void* acmonStatic = Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "ACMON", "StaticUpdate", 0);
  void* kubeBan = Il2CppGetMethodOffset("Assembly-CSharp.dll", "kube", "Kube", "Ban", 1);
  void* kubeIsBanned = Il2CppGetMethodOffset("Assembly-CSharp.dll", "kube", "Kube", "IsBanned", 1);
  void* ohBanned = Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "ObjectsHolderScript", "Banned", 1);

  HookVoid("ACMON::SlowUpdate", acmonSlow, (void*)hook_ACMON_SlowUpdate, (void**)&orig_ACMON_SlowUpdate);
  HookVoid("ACMON::MyUpdate", acmonMy, (void*)hook_ACMON_MyUpdate, (void**)&orig_ACMON_MyUpdate);
  HookVoid("ACMON::StaticUpdate", acmonStatic, (void*)hook_ACMON_StaticUpdate, (void**)&orig_ACMON_StaticUpdate);
  HookVoid("kube.Kube::Ban", kubeBan, (void*)hook_Kube_Ban, (void**)&orig_Kube_Ban);
  HookVoid("kube.Kube::IsBanned", kubeIsBanned, (void*)hook_Kube_IsBanned, (void**)&orig_Kube_IsBanned);
  HookVoid("ObjectsHolderScript::Banned", ohBanned, (void*)hook_ObjectsHolder_Banned, (void**)&orig_ObjectsHolder_Banned);

  if (!Player_get_islocal || !Component_get_transform || !Transform_get_position || !Transform_set_position) {
    LOGD("critical IL2CPP methods missing; PlayerScript hook disabled");
    ImGuiOK = true;
    return;
  }

  void* playerUpdate = Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "PlayerScript", "Update", 0);
  if (playerUpdate != nullptr) {
    if (DobbyHook(playerUpdate, (void*)hook_Player_Update, (void**)&orig_Player_Update) == 0) {
      LOGD("PlayerScript::Update hooked for Fly/SafePhase NoClip + ACMON bypass + ESP tracking v17");
    } else {
      LOGD("DobbyHook PlayerScript::Update failed");
    }
  } else {
    LOGD("PlayerScript::Update not found");
  }

  void* playerStart = Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "PlayerScript", "Start", 0);
  if (playerStart != nullptr) {
    if (DobbyHook(playerStart, (void*)hook_Player_Start, (void**)&orig_Player_Start) == 0) {
      LOGD("PlayerScript::Start hooked for ESP tracking");
    } else {
      LOGD("DobbyHook PlayerScript::Start failed");
    }
  } else {
    LOGD("PlayerScript::Start not found");
  }

  void* playerInit = Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "PlayerScript", "Init", 0);
  if (playerInit != nullptr) {
    if (DobbyHook(playerInit, (void*)hook_Player_Init, (void**)&orig_Player_Init) == 0) {
      LOGD("PlayerScript::Init hooked for ESP tracking");
    } else {
      LOGD("DobbyHook PlayerScript::Init failed");
    }
  } else {
    LOGD("PlayerScript::Init not found");
  }

  void* playerLateUpdate = Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "PlayerScript", "LateUpdate", 0);
  if (playerLateUpdate != nullptr) {
    if (DobbyHook(playerLateUpdate, (void*)hook_Player_LateUpdate, (void**)&orig_Player_LateUpdate) == 0) {
      LOGD("PlayerScript::LateUpdate hooked for ESP tracking");
    } else {
      LOGD("DobbyHook PlayerScript::LateUpdate failed");
    }
  } else {
    LOGD("PlayerScript::LateUpdate not found");
  }

  void* playerOnDestroy = Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "PlayerScript", "OnDestroy", 0);
  if (playerOnDestroy != nullptr) {
    if (DobbyHook(playerOnDestroy, (void*)hook_Player_OnDestroy, (void**)&orig_Player_OnDestroy) == 0) {
      LOGD("PlayerScript::OnDestroy hooked for ESP cleanup");
    } else {
      LOGD("DobbyHook PlayerScript::OnDestroy failed");
    }
  } else {
    LOGD("PlayerScript::OnDestroy not found");
  }

  LOGD("ESP resolve: Camera_WorldToScreenPoint=%p Player_get_height=%p Player_getTeam=%p", (void*)Camera_WorldToScreenPoint, (void*)Player_get_height, (void*)Player_getTeam);

  ImGuiOK = true;
}


// Forward declaration required because StartCtfAgentOnce references hack_thread before its definition.
void hack_thread(pid_t pid);

static std::atomic_bool g_CtfAgentStarted{false};

static void StartCtfAgentOnce(const char* reason) {
  bool expected = false;
  if (!g_CtfAgentStarted.compare_exchange_strong(expected, true)) {
    LOGD("CTF agent already started; reason=%s", reason ? reason : "unknown");
    return;
  }

  LOGD("CTF agent starting; package=com.Nobodyshot.kuboom reason=%s", reason ? reason : "unknown");
  std::thread thread_hack(hack_thread, getpid());
  thread_hack.detach();
}

void hack_thread(pid_t pid) {
  (void)pid;

  // Loader/CTF mode: start wherever the loader placed this library.
  // Package-name filtering is intentionally disabled because some loaders/injectors
  // expose a process name that does not exactly match the game's package.
  LOGD("hack_thread started; package=com.Nobodyshot.kuboom package gate disabled");
  sleep(1);
  StartGUI();
}

extern "C"
JNIEXPORT jint JNICALL Agent_OnAttach(JavaVM *vm, char *options, void *reserved) {
  (void)vm;
  (void)options;
  (void)reserved;

  // Entry point used by: adb shell am attach-agent com.Nobodyshot.kuboom <path>/libctfagent.so
  StartCtfAgentOnce("Agent_OnAttach");
  return JNI_OK;
}

extern "C"
JNIEXPORT jint JNICALL Agent_OnLoad(JavaVM *vm, char *options, void *reserved) {
  (void)vm;
  (void)options;
  (void)reserved;

  // Optional entry point for other debuggable/JVMTI loaders.
  StartCtfAgentOnce("Agent_OnLoad");
  return JNI_OK;
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void * reserved) {
  JNIEnv *env;
  vm->GetEnv((void **) &env, JNI_VERSION_1_6);
  return JNI_VERSION_1_6;
}

__attribute__((constructor))
void lib_main() {
  // Kept for classic dlopen/Zygisk/manual loaders. The atomic guard prevents a double
  // start when Android calls the JVMTI Agent_OnAttach entry point after constructors.
  StartCtfAgentOnce("constructor");
}
